# Bilgi Koleji Destek — VPS kurulumu

## 1. Alan adı ve sunucu

Linux VPS üzerinde Docker Engine ve Compose eklentisi kurulu olmalıdır: https://docs.docker.com/engine/install/

Kullanacağınız alt alan adının A kaydını VPS IPv4 adresine yönlendirin. IPv6 kullanmıyorsanız hatalı AAAA kaydı bırakmayın. Sunucu ve sağlayıcı güvenlik duvarında TCP 80/443 açık olsun; SSH erişiminizi koruyun. Aynı portları kullanan Nginx/Apache varsa bu kurulumla aynı anda çalıştırmayın; mevcut ters proxy'nizi kullanacaksanız yapılandırmayı uyarlayın.

Caddy alan adı için HTTPS sertifikası alır. DNS ve dış erişim hazır olmalıdır. Kaynak: https://caddyserver.com/docs/automatic-https

## 2. Dosyaları hazırlayın

ZIP'i VPS'e çıkarın, `akilli-tahta` klasörüne girin. Aşağıdaki alan adını **kendi gerçek alan adınızla değiştirin**:

```bash
python3 configure.py --domain destek.kurumunuz.com
```

Bu komut `.env` oluşturur; SECRET_KEY üretir, varsa mevcut anahtarı korur. PUBLIC_BASE_URL, SITE_DOMAIN ve üretim ayarlarını düzenler. `.env.example` dosyasını bunun üzerine kopyalamayın.

Yeni kurulumda `.env` dosyasına güçlü, en az 12 karakterlik bir ilk yönetici parolası yazın:

```dotenv
INITIAL_ADMIN_PASSWORD=BURAYA_KENDI_ILK_PAROLANIZI_YAZIN
```

Bu satır mevcut yönetici hesabının parolasını değiştirmez. İlk kurulumdan sonra kaldırın. Tanımlamazsanız README'deki ilk kurulum parolası kullanılır ve girişte değiştirmeniz istenir.

Varsa eski bilgisayara özgü `DATABASE_URL` satırını kaldırın: varsayılan SQLite yolu container içinde `/app/instance/tahta.db` olur. Mevcut veriyi bu klasöre taşımadan yeni boş veritabanına başlamayın.

```bash
sudo chown -R 10001:10001 instance
docker compose up -d --build
docker compose ps
docker compose logs --tail=100 init web caddy
```

`init` işlemi migration ve başlangıç verilerini oluşturduktan sonra başarıyla kapanır; bu normaldir. Web, Redis ve Caddy çalışır durumda kalır. İlk build/sertifika işlemi birkaç dakika sürebilir.

## 3. İlk kullanım

Kendi `https://...` adresinizi açın. Sayfanın altındaki Yönetici Girişi bağlantısını kullanın; kullanıcı adı `emre`. İlk girişte parolayı değiştirin. Yönetici → Sınıf ve Şubeler bölümünden gerçek şubeleri ekleyin. E-posta, K12 ve diğer talepler için şube eklemek gerekmez.

Telefonunuzda aynı HTTPS adresini açın. Ana sayfadaki “Nasıl ekleyeceğimi göster” bağlantısı Android/iPhone kurulumunu anlatır. Bu bir web uygulamasıdır; APK veya App Store indirmesi gerekmez. İnternet bağlantısı talep göndermek için gereklidir.

QR kodlarını yeni alan adı ayarlandıktan sonra yeniden indirin. Önceden basılmış 127.0.0.1 veya yerel IP içeren QR kodları kendiliğinden değişmez.

## Eski sürümden geçiş

1. Eski uygulamayı durdurun; `.env` ve **instance klasörünün tamamını** güvenli başka bir konuma yedekleyin. Veritabanı ve fotoğraflar birlikte taşınmalı.
2. Yeni kodu ayrı klasöre çıkarın. Eski `.env` ve `instance/` klasörünü bu klasöre kopyalayın. SECRET_KEY değerini koruyun.
3. Yukarıdaki `configure.py` komutunu çalıştırın. Eski makineye ait DATABASE_URL yolunu kaldırın veya yeni ortama uygun düzenleyin.
4. Dosya sahipliğini ayarlayın ve Compose'u başlatın. Migration mevcut tahta kayıtlarını, cevapları, fotoğraf bağlantılarını ve geçmişi korur; yeni destek alanlarını ekler. `seed` mevcut hesap/parolayı sıfırlamaz.
5. Yönetici panelinden eski kayıt ve fotoğrafları kontrol edin. Eski yedeği bu doğrulama tamamlanana kadar saklayın.

Sonraki Docker sürüm güncellemelerinde önce yedek alın; migration sırasında web hizmetini durdurun:

```bash
docker compose stop caddy web
docker compose build
docker compose run --rm init
docker compose up -d
```

Migration başarısızsa web'i başlatmadan hatayı inceleyin. `docker compose down -v` kullanmayın: kalıcı servis volume'larını siler.

## Yedekleme ve bakım

Tutarlı dosya yedeği için önce `docker compose stop caddy web` ile yazmaları durdurun. `.env` ve `instance/` klasörünü güvenli konuma kopyalayın, ardından `docker compose up -d` ile açın. Yedekte kişisel bilgiler vardır; herkese açık dizine koymayın. Geri yüklemeyi ayrı ortamda deneyin.

Geçici soru oturumlarını temizlemek için:

```bash
docker compose exec web python -m flask --app run cleanup-drafts
```

API anahtarı isteğe bağlıdır. Gemini ayarı için README'ye bakın; `.env` değişince `docker compose up -d --force-recreate web` çalıştırın. Hesabınızın erişebildiği model adını seçin. E-posta/K12 akışları API gerektirmez.

E-posta sıfırlama burada yalnız destek talebidir. Otomatik parola sıfırlama, e-posta gönderimi ve K12 yönetim API bağlantısı kurulmamıştır.

## Sorun giderme

- Site açılmıyor: DNS, sunucu güvenlik duvarı, 80/443 portları ve `docker compose ps` çıktısını kontrol edin.
- HTTPS alınmıyor: `docker compose logs caddy`; DNS/AAAA kayıtlarını ve dış erişimi kontrol edin.
- Veritabanına yazılamıyor: `instance` sahipliği UID/GID 10001 olmalı.
- QR eski IP'yi açıyor: `.env` PUBLIC_BASE_URL değerini düzeltin, web container'ını yeniden oluşturun ve yeni QR indirin.
- Okulun ortak IP'sinde 429: bildirim hız limitlerini kurumun eşzamanlı kullanımına göre ayarlayın (routes/public.py).

Bu paket VPS'e kurulmaya hazırlanmıştır; gerçek sunucuya dağıtım ve TLS kurulumu teslimat ortamında çalıştırılmamıştır.

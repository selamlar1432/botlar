"""Generate/preserve VPS settings without exposing secrets. Run before Compose."""
import argparse
import os
from pathlib import Path
import re
import secrets

def main():
    parser=argparse.ArgumentParser(description='Bilgi Koleji Destek VPS yapılandırması')
    parser.add_argument('--domain', required=True, help='Örn: destek.kurumunuz.com (https:// olmadan)')
    args=parser.parse_args()
    domain=args.domain.strip().lower()
    if not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}', domain) or domain.endswith(('.example','.local','.localhost')):
        parser.error('Gerçek alan adınızı yazın; protokol, port veya yol eklemeyin.')
    path=Path(__file__).resolve().parent/'.env'
    content=path.read_text() if path.exists() else ''
    entries={line.split('=',1)[0].strip():line.split('=',1)[1].strip() for line in content.splitlines() if '=' in line and not line.lstrip().startswith('#')}
    updates={'APP_ENV':'production','SITE_DOMAIN':domain,'PUBLIC_BASE_URL':'https://'+domain,'RATELIMIT_STORAGE_URI':'redis://redis:6379/0','TRUST_PROXY':'1'}
    key=entries.get('SECRET_KEY','')
    if len(key)<32 or key.startswith('REPLACE_'):updates['SECRET_KEY']=secrets.token_hex(32)
    if 'GEMINI_API_KEY' not in entries:updates['GEMINI_API_KEY']=''
    # Preserve existing secret keys and Gemini choice; do not guess model access.
    out=[];seen=set()
    for line in content.splitlines():
        name=line.split('=',1)[0].strip() if '=' in line and not line.lstrip().startswith('#') else ''
        if name in updates:
            if name not in seen:out.append(name+'='+updates[name]);seen.add(name)
        else:out.append(line)
    out.extend(name+'='+value for name,value in updates.items() if name not in seen)
    path.write_text('\n'.join(out)+'\n');os.chmod(path,0o600)
    (path.parent/'instance'/'uploads').mkdir(parents=True,exist_ok=True)
    print('VPS ayarları hazır: https://'+domain)
    print('Mevcut SECRET_KEY ve API anahtarları korundu. Yeni kurulumsa ilk yönetici şifrenizi .env içinde INITIAL_ADMIN_PASSWORD olarak belirleyebilirsiniz.')
    print('Devam: sudo chown -R 10001:10001 instance && docker compose up -d --build')
if __name__=='__main__':main()

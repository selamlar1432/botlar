from flask import abort, request

def field(name, minimum=0, maximum=200, default=''):
    value = request.form.get(name, default).strip()
    if not minimum <= len(value) <= maximum: abort(400, description=f'{name}: alan uzunluğu geçersiz.')
    return value

def number(name, minimum=1, maximum=2**31-1):
    try: value = int(request.form.get(name, ''))
    except (TypeError, ValueError): abort(400, description='Geçerli bir seçim yapın.')
    if not minimum <= value <= maximum: abort(400, description='Seçim aralık dışında.')
    return value

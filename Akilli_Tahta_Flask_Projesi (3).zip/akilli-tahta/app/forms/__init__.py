from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import DataRequired, Length

class LoginForm(FlaskForm):
    username = StringField('Kullanıcı adı', validators=[DataRequired(), Length(max=80)])
    password = PasswordField('Şifre', validators=[DataRequired(), Length(max=200)])

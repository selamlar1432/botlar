import os
import hmac
from pathlib import Path
from datetime import timezone
from zoneinfo import ZoneInfo
import click
from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_login import current_user
from werkzeug.middleware.proxy_fix import ProxyFix
from .extensions import db, login, csrf, migrate, limiter
from .models import AdminUser, AppSettings, Draft, AuditLog, STATUS, PRIORITIES, GradeLevel, IssueCategory, SERVICES, now


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object('config.Config')
    if test_config: app.config.update(test_config)
    if len(app.config['SECRET_KEY']) < 32 or app.config['SECRET_KEY'].startswith('REPLACE_'):
        raise RuntimeError('Önce .env dosyasında rastgele en az 32 karakter SECRET_KEY oluşturun.')
    if app.config['APP_ENV'] == 'production' and not app.testing and app.config['RATELIMIT_STORAGE_URI'] == 'memory://':
        raise RuntimeError('Üretim ortamında ortak Redis hız sınırı deposu ayarlayın.')
    if app.config['APP_ENV'] == 'production' and not app.testing:
        from urllib.parse import urlsplit
        parsed = urlsplit(app.config['PUBLIC_BASE_URL'])
        if (parsed.scheme != 'https' or not parsed.hostname or parsed.hostname in {'localhost', '127.0.0.1', '::1'} or parsed.hostname.endswith('.example') or parsed.path or parsed.query or parsed.fragment or parsed.username):
            raise RuntimeError('Üretimde PUBLIC_BASE_URL gerçek HTTPS alan adınız olmalıdır; localhost veya örnek alan adı kullanmayın.')
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    Path(app.config['UPLOAD_FOLDER']).mkdir(parents=True, exist_ok=True)
    if app.config['TRUST_PROXY']:
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)  # one trusted reverse proxy only
    for extension in (db, login, csrf, limiter): extension.init_app(app)
    migrate.init_app(app, db, render_as_batch=True)
    login.login_view = 'auth.login_page'
    login.login_message = 'Bu alan için yönetici girişi yapın.'

    @login.user_loader
    def load_user(user_id):
        parts = user_id.split(':', 1)
        if len(parts) != 2 or not parts[0].isdigit(): return None
        user = db.session.get(AdminUser, int(parts[0]))
        return user if user and hmac.compare_digest(user.get_id(), user_id) else None

    from .routes.public import bp as public
    from .routes.auth import bp as auth
    from .routes.admin import bp as admin
    for blueprint in (public, auth, admin): app.register_blueprint(blueprint)

    @app.before_request
    def force_password_change():
        if current_user.is_authenticated and current_user.must_change_password and request.endpoint not in {'auth.password', 'auth.logout', 'static'}:
            return redirect(url_for('auth.password'))

    @app.after_request
    def security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'"
        if request.is_secure: response.headers['Strict-Transport-Security'] = 'max-age=31536000'
        if request.endpoint != 'static': response.headers['Cache-Control'] = 'no-store'
        return response

    @app.context_processor
    def context():
        return {'settings': db.session.get(AppSettings, 1), 'statuses': STATUS, 'priorities': PRIORITIES, 'services': SERVICES}

    @app.template_filter('trdate')
    def trdate(value):
        if not value: return 'Henüz bildirim yok'
        return value.replace(tzinfo=timezone.utc).astimezone(ZoneInfo('Europe/Istanbul')).strftime('%d.%m.%Y %H:%M')

    def error_page(error):
        code = getattr(error, 'code', 500)
        messages = {400: 'Bilgileri kontrol edip tekrar deneyin. Oturum süresi dolduysa sayfayı yenileyin.', 403: 'Bu işlem için yetkiniz bulunmuyor.', 404: 'Aradığınız kayıt bulunamadı.', 409: 'Kayıt değişti. Sayfayı yenileyip tekrar deneyin.', 413: 'Yükleme boyutu sınırı aşıldı. En fazla 3 adet, her biri 5 MB fotoğraf yükleyin.', 429: 'Çok sayıda deneme yapıldı. Lütfen kısa bir süre sonra yeniden deneyin.', 500: 'İşlem tamamlanamadı. Lütfen tekrar deneyin.'}
        if code == 500: db.session.rollback()
        message = messages.get(code, 'İşlem tamamlanamadı.')
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest': return jsonify(error=message), code
        return render_template('error.html', code=code, message=message), code
    for code in [400, 403, 404, 409, 413, 429, 500]: app.register_error_handler(code, error_page)

    @app.cli.command('seed')
    def seed():
        """Create levels, default categories, settings and first administrator. Idempotent."""
        from .services.questions import SETS, COMMON
        for n in range(1, 13):
            if not GradeLevel.query.filter_by(number=n).first(): db.session.add(GradeLevel(number=n))
        for name, questions in SETS.items():
            if not IssueCategory.query.filter_by(name=name).first():
                extra = [q for q in COMMON if q not in questions]
                db.session.add(IssueCategory(name=name, questions=(questions + extra)[:5]))
        for service, names in {
            'email': ['E-posta şifremi sıfırlamak istiyorum'],
            'k12': ['K12 hesabıma giriş yapamıyorum', 'K12 üzerinde işlem yapamıyorum', 'K12 ile ilgili başka bir sorun'],
            'other': ['Bilgisayar veya yazıcı sorunu', 'Diğer teknik destek talebi']
        }.items():
            for name in names:
                if not IssueCategory.query.filter_by(name=name).first():
                    db.session.add(IssueCategory(name=name, service=service, questions=[]))
        settings = db.session.get(AppSettings, 1)
        if not settings: db.session.add(AppSettings(id=1))
        elif settings.institution == 'Akıllı Tahta Yönetim Sistemi': settings.institution = 'Bilgi Koleji'
        if not AdminUser.query.filter_by(username='emre').first():
            user = AdminUser(username='emre')
            user.set_password(os.getenv('INITIAL_ADMIN_PASSWORD') or 'akilitahtalar123456')
            db.session.add(user)
        db.session.commit()
        click.echo('12 seviye ve başlangıç hesabı hazır. Şubeleri yönetim panelinden ekleyin.')

    @app.cli.command('cleanup-drafts')
    def cleanup_drafts():
        """Remove expired anonymous questionnaire drafts only, never issue records."""
        from datetime import timedelta
        count = Draft.query.filter(Draft.created_at < now() - timedelta(days=1)).delete()
        db.session.commit()
        click.echo(f'{count} geçici soru oturumu temizlendi.')

    return app

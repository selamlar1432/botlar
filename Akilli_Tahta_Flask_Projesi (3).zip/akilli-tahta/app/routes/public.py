import secrets
from datetime import timedelta
from pathlib import Path
from flask import Blueprint, render_template, request, jsonify, session, abort, current_app, url_for, send_from_directory
from sqlalchemy.exc import IntegrityError
from ..extensions import db, limiter
from ..models import Classroom, GradeLevel, IssueCategory, Issue, IssueAnswer, IssuePhoto, IssueStatusHistory, AIAnalysis, AppSettings, Draft, SERVICES, now
from ..services import gemini
from ..services.uploads import save_image, remove_images
from ..utils import field, number

bp = Blueprint('public', __name__)

def snapshot():
    rooms = Classroom.query.filter_by(active=True).all()
    data = [{'id': r.id, 'name': r.name, 'grade': r.grade.number, 'state': r.state, 'active_count': r.active_count,
             'last': max((i.created_at for i in r.issues), default=None)} for r in rooms]
    for row in data:
        row['last'] = current_app.jinja_env.filters['trdate'](row['last'])
    data.sort(key=lambda r: (r['grade'], r['name']))
    return {'rooms': data, 'stats': {'total': len(rooms), 'problem': sum(r.active_count > 0 for r in rooms), 'reviewing': Issue.query.filter_by(status='reviewing', service='board').count(), 'resolved': Issue.query.filter_by(status='resolved', service='board').count()}}

@bp.get('/')
def home():
    return render_template('home.html')

@bp.get('/siniflar')
def classrooms():
    return render_template('class_status.html', data=snapshot(), grades=GradeLevel.query.order_by(GradeLevel.number).all())

@bp.get('/telefonuma-ekle')
def install_page(): return render_template('install.html')

@bp.get('/healthz')
def health():
    from sqlalchemy import text
    db.session.execute(text('SELECT 1'))
    return jsonify(status='ok')

@bp.get('/api/durum')
@limiter.limit('120 per minute')
def state(): return jsonify(snapshot())

@bp.get('/bildir')
def report():
    if 'draft_owner' not in session: session['draft_owner'] = secrets.token_urlsafe(32)
    if 'submission_key' not in session or Issue.query.filter_by(submission_key=session['submission_key']).first():
        session['submission_key'] = secrets.token_urlsafe(32)
    service = request.args.get('service', 'board')
    if service not in SERVICES: abort(404)
    if service != 'board':
        return render_template('support_report.html', service=service, categories=IssueCategory.query.filter_by(active=True, service=service).all(), submission_key=session['submission_key'])
    return render_template('report.html', service='board', rooms=Classroom.query.filter_by(active=True).join(GradeLevel).order_by(GradeLevel.number, Classroom.branch).all(), categories=IssueCategory.query.filter_by(active=True, service='board').order_by(IssueCategory.id).all(), selected=request.args.get('classroom', type=int), submission_key=session['submission_key'])

def get_draft(draft_id):
    draft = db.session.get(Draft, draft_id)
    if not draft or draft.owner != session.get('draft_owner') or draft.created_at < now() - timedelta(hours=8):
        abort(400, description='Soru oturumunuz sona erdi. Lütfen yeniden başlayın.')
    return draft

def draft_response(draft):
    question = draft.catalog[draft.pending] if draft.pending is not None else None
    return jsonify(id=draft.id, complete=draft.complete, question=question, count=len(draft.answers), ai=draft.use_ai, answers=draft.answers)

@bp.post('/api/sorular/basla')
@limiter.limit('20 per hour')
def start_questions():
    payload = request.get_json()
    if not isinstance(payload, dict) or type(payload.get('category')) is not int: abort(400)
    category = db.get_or_404(IssueCategory, payload['category'])
    if not category.active or category.service != 'board': abort(400)
    if 'draft_owner' not in session: session['draft_owner'] = secrets.token_urlsafe(32)
    settings = db.session.get(AppSettings, 1)
    draft = Draft(owner=session['draft_owner'], category_id=category.id, catalog=category.questions, answers=[], use_ai=bool(payload.get('ai') is True and settings.ai_enabled and current_app.config['GEMINI_API_KEY']))
    draft.pending = gemini.next_question(draft)
    db.session.add(draft)
    db.session.commit()
    return draft_response(draft)

@bp.post('/api/sorular/<draft_id>')
@limiter.limit('100 per hour')
def answer_question(draft_id):
    draft = get_draft(draft_id)
    payload = request.get_json()
    if not isinstance(payload, dict): abort(400)
    if payload.get('back') is True:
        if draft.answers:
            removed = draft.answers[-1]
            draft.answers = draft.answers[:-1]
            draft.pending = removed['index']
            draft.complete = False
    elif payload.get('disable_ai') is True:
        draft.use_ai = False
    else:
        if draft.complete or draft.pending is None: abort(409)
        question = draft.catalog[draft.pending]
        answer = payload.get('answer')
        if answer not in question['options']: abort(400)
        draft.answers = draft.answers + [{'index': draft.pending, 'question': question['text'], 'answer': answer}]
        # Three observations are the low-friction default. Never more than 7.
        draft.complete = len(draft.answers) >= min(3, len(draft.catalog), 7)
        draft.pending = None if draft.complete else gemini.next_question(draft)
    db.session.commit()
    return draft_response(draft)

@bp.post('/api/bildirim')
@limiter.limit('8 per hour; 25 per day')
def submit_issue():
    key = field('submission_key', 20, 64)
    if key != session.get('submission_key'): abort(400)
    existing = Issue.query.filter_by(submission_key=key).first()
    if existing: return jsonify(number=existing.number, url=url_for('public.success', issue_number=existing.number))
    if request.form.get('website'): abort(400)
    service = field('service', default='board')
    if service not in SERVICES: abort(400)
    category = db.get_or_404(IssueCategory, number('category'))
    if not category.active or category.service != service: abort(400)
    room = db.get_or_404(Classroom, number('classroom')) if service == 'board' else None
    if room and not room.active: abort(400)
    account = field('account', 0, 200)
    if service == 'email':
        import re
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', account):
            return jsonify(error='Şifresi sıfırlanacak e-posta adresini yazın.'), 400
    if service == 'k12' and not account:
        return jsonify(error='K12 kullanıcı adınızı veya kayıtlı e-posta adresinizi yazın.'), 400
    teacher = field('teacher', 3, 120)
    description = field('description', 5, 4000)
    contact = field('contact', 0, 200)
    if room and room.active_count and request.form.get('different') != 'yes':
        return jsonify(error='Bu sınıfta açık bildirim var. Farklı bir sorun olduğunu onaylayın.', duplicate=True), 409
    draft = get_draft(field('draft_id', 20, 64)) if service == 'board' else None
    if draft and (not draft.complete or draft.category_id != category.id): abort(400)
    files = [f for f in request.files.getlist('photos') if f.filename]
    if len(files) > 3: return jsonify(error='En fazla 3 fotoğraf ekleyin.'), 400
    saved = []
    try:
        for file in files: saved.append(save_image(file))
    except ValueError as exc:
        remove_images(saved)
        return jsonify(error=str(exc)), 400
    issue = Issue(classroom_id=room.id if room else None, service=service, account=account, category_id=category.id, teacher=teacher, contact=contact, description=description, submission_key=key)
    try:
        db.session.add(issue)
        db.session.flush()
        for a in (draft.answers if draft else []): db.session.add(IssueAnswer(issue_id=issue.id, question=a['question'], answer=a['answer']))
        for name in saved: db.session.add(IssuePhoto(issue_id=issue.id, filename=name))
        db.session.add(IssueStatusHistory(issue_id=issue.id, status='reported', actor='Öğretmen', note='Arıza bildirildi.'))
        # Save the real issue BEFORE calling any optional external service.
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        remove_images(saved)
        existing = Issue.query.filter_by(submission_key=key).first()
        if existing: return jsonify(number=existing.number, url=url_for('public.success', issue_number=existing.number))
        raise
    except Exception:
        db.session.rollback()
        remove_images(saved)
        raise
    if draft and draft.use_ai and db.session.get(AppSettings, 1).ai_enabled:
        analysis = gemini.analyze(category.name, draft.answers)
        if analysis:
            try:
                db.session.add(AIAnalysis(issue_id=issue.id, data=analysis, model=current_app.config['GEMINI_MODEL']))
                db.session.commit()
            except Exception:
                db.session.rollback()
                current_app.logger.warning('Analysis storage failed for issue %s', issue.id)
    return jsonify(number=issue.number, url=url_for('public.success', issue_number=issue.number)), 201

@bp.get('/tamamlandi/<issue_number>')
def success(issue_number):
    issue = Issue.query.filter_by(submission_key=session.get('submission_key', '')).first_or_404()
    if issue.number != issue_number: abort(404)
    return render_template('success.html', issue=issue)

@bp.post('/yeni-bildirim')
def new_report():
    from flask import redirect
    session['submission_key'] = secrets.token_urlsafe(32)
    return redirect(url_for('public.report'))

@bp.get('/takip')
@limiter.limit('30 per minute')
def track():
    code = request.args.get('q', '').strip().upper()
    issue = None
    if code:
        try:
            candidate = db.session.get(Issue, int(code.rsplit('-', 1)[1]))
            if candidate and candidate.number == code: issue = candidate
        except (ValueError, IndexError): pass
    return render_template('track.html', issue=issue, code=code)

@bp.get('/yardim')
def help_page(): return render_template('help.html')

@bp.get('/gizlilik')
def privacy(): return render_template('privacy.html')

@bp.get('/kurum-logo')
def logo():
    name = db.session.get(AppSettings, 1).logo
    if not name: return current_app.send_static_file('bilgi-logo.png')
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], name, mimetype='image/jpeg')

@bp.get('/manifest.webmanifest')
def manifest():
    return jsonify(name=db.session.get(AppSettings, 1).institution + ' Destek', short_name='Bilgi Destek', lang='tr', id='/', start_url='/', scope='/', display='standalone', background_color='#f4f6fa', theme_color='#132a49', icons=[{'src': f'/static/icon-{size}.png', 'sizes': f'{size}x{size}', 'type': 'image/png', 'purpose': 'any maskable'} for size in (192, 512)])

@bp.get('/sw.js')
def sw(): return current_app.send_static_file('sw.js')

@bp.get('/offline')
def offline(): return current_app.send_static_file('offline.html')

import csv
import io
import json
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import qrcode
from flask import Blueprint, request, render_template, redirect, url_for, flash, abort, send_from_directory, current_app, Response, send_file
from flask_login import login_required, current_user
from sqlalchemy import func, cast, String
from sqlalchemy.exc import IntegrityError
from ..extensions import db
from ..models import Issue, Classroom, GradeLevel, IssueCategory, AppSettings, IssuePhoto, AuditLog, STATUS, PRIORITIES, SERVICES, now
from ..services.issues import update_issue
from ..services.questions import validate_catalog, COMMON
from ..services.uploads import save_image, remove_images
from ..utils import field, number

bp = Blueprint('admin', __name__, url_prefix='/yonetici')
@bp.before_request
@login_required
def protect(): pass

def audit(action): db.session.add(AuditLog(actor=current_user.username, action=action))

def filtered_issues():
    query = Issue.query
    service = request.args.get('service', '')
    if service in SERVICES: query = query.filter_by(service=service)
    status = request.args.get('status', '')
    if status in STATUS: query = query.filter_by(status=status)
    room = request.args.get('classroom', type=int)
    category = request.args.get('category', type=int)
    if room: query = query.filter_by(classroom_id=room)
    if category: query = query.filter_by(category_id=category)
    archive = request.args.get('archive', '')
    if archive != 'all': query = query.filter_by(archived=(archive == 'yes'))
    for key, end in [('start', False), ('end', True)]:
        text = request.args.get(key)
        if text:
            try:
                date = datetime.strptime(text, '%Y-%m-%d').replace(tzinfo=ZoneInfo('Europe/Istanbul'))
                if end: date += timedelta(days=1)
                date = date.astimezone(timezone.utc).replace(tzinfo=None)
            except ValueError: abort(400)
            query = query.filter(Issue.created_at < date) if end else query.filter(Issue.created_at >= date)
    search = request.args.get('q', '').strip()
    if search:
        if search.upper().startswith('AT-'):
            try: query = query.filter(Issue.id == int(search.rsplit('-', 1)[-1]))
            except ValueError: query = query.filter(Issue.id == -1)
        else:
            query = query.join(Classroom).join(GradeLevel).filter((cast(GradeLevel.number, String) + '-' + Classroom.branch).ilike('%' + search[:40] + '%'))
    return query.order_by(Issue.created_at.desc())

@bp.get('/')
def dashboard():
    stats = {'total': Issue.query.count(), 'active': Issue.query.filter(Issue.status != 'resolved').count(), 'reviewing': Issue.query.filter_by(status='reviewing').count(), 'resolved': Issue.query.filter_by(status='resolved').count(), 'week': Issue.query.filter(Issue.created_at >= now() - timedelta(days=7)).count()}
    top = db.session.query(Classroom, func.count(Issue.id)).join(Issue).group_by(Classroom.id).order_by(func.count(Issue.id).desc()).limit(5).all()
    pages = filtered_issues().paginate(page=request.args.get('page', 1, type=int), per_page=20, error_out=False)
    return render_template('admin.html', stats=stats, top=top, pages=pages, rooms=Classroom.query.all(), categories=IssueCategory.query.all())

@bp.route('/bildirim/<int:issue_id>', methods=['GET', 'POST'])
def detail(issue_id):
    issue = db.get_or_404(Issue, issue_id)
    if request.method == 'POST':
        status, priority, note = field('status'), field('priority'), field('note', 0, 4000)
        if status not in {'reported', 'reviewing', 'resolved'} or priority not in PRIORITIES: abort(400)
        if issue.status != 'resolved' and status == 'resolved' and len(note) < 3:
            flash('Çözüm için yapılan müdahaleyi kısaca yazın.', 'error')
        else:
            update_issue(issue, status, priority, note, current_user.username)
            audit(f'{issue.number}: durum/not/öncelik güncellendi')
            db.session.commit()
            flash('Bildirim güncellendi.', 'success')
            return redirect(url_for('admin.detail', issue_id=issue.id))
    return render_template('detail.html', issue=issue)

@bp.post('/bildirim/<int:issue_id>/arsiv')
def archive(issue_id):
    issue = db.get_or_404(Issue, issue_id)
    if issue.status != 'resolved': abort(400)
    issue.archived = not issue.archived
    audit(f'{issue.number}: arşiv={issue.archived}')
    db.session.commit()
    flash('Arşiv durumu güncellendi. Kayıt silinmedi.', 'success')
    return redirect(url_for('admin.detail', issue_id=issue.id))

@bp.get('/fotograf/<int:photo_id>')
def photo(photo_id):
    photo = db.get_or_404(IssuePhoto, photo_id)
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], photo.filename, mimetype='image/jpeg')

@bp.route('/siniflar', methods=['GET', 'POST'])
def classrooms():
    if request.method == 'POST':
        room_id = request.form.get('id', type=int)
        room = db.get_or_404(Classroom, room_id) if room_id else Classroom()
        grade = db.get_or_404(GradeLevel, number('grade'))
        room.grade_id, room.branch = grade.id, field('branch', 1, 20).upper()
        room.active = request.form.get('active') == 'yes'
        if not room.active and room_id and room.active_count:
            flash('Aktif arızaları bulunan şube pasifleştirilemez. Önce arızaları sonuçlandırın.', 'error')
            db.session.rollback()
        else:
            db.session.add(room)
            audit(f'Şube güncellendi: {grade.number}-{room.branch}')
            try:
                db.session.commit()
                flash('Şube kaydedildi.', 'success')
            except IntegrityError:
                db.session.rollback()
                flash('Bu sınıf ve şube zaten mevcut.', 'error')
        return redirect(url_for('admin.classrooms'))
    return render_template('classrooms.html', rooms=Classroom.query.join(GradeLevel).order_by(GradeLevel.number, Classroom.branch).all(), grades=GradeLevel.query.order_by(GradeLevel.number).all())

@bp.get('/sinif/<int:room_id>')
def classroom_history(room_id):
    room = db.get_or_404(Classroom, room_id)
    return render_template('classroom_history.html', room=room, issues=Issue.query.filter_by(classroom_id=room.id).order_by(Issue.created_at.desc()).all())

@bp.get('/sinif/<int:room_id>/qr.png')
def qr(room_id):
    room = db.get_or_404(Classroom, room_id)
    image = qrcode.make(current_app.config['PUBLIC_BASE_URL'] + url_for('public.report', classroom=room.id))
    output = io.BytesIO()
    image.save(output, format='PNG')
    output.seek(0)
    return send_file(output, mimetype='image/png', as_attachment=True, download_name=f'sinif-{room.name}-qr.png')

@bp.route('/ayarlar', methods=['GET', 'POST'])
def settings_page():
    settings = db.session.get(AppSettings, 1)
    if request.method == 'POST':
        institution = field('institution', 3, 120)
        retention = number('retention_days', 30, 3650)
        new_logo = None
        file = request.files.get('logo')
        if file and file.filename:
            try: new_logo = save_image(file)
            except ValueError as exc:
                flash(str(exc), 'error')
                return redirect(url_for('admin.settings_page'))
        old_logo = settings.logo
        settings.institution = institution
        settings.ai_enabled = request.form.get('ai_enabled') == 'yes'
        settings.retention_days = retention
        if new_logo: settings.logo = new_logo
        audit('Kurum ve yapay zekâ ayarları güncellendi')
        try: db.session.commit()
        except Exception:
            db.session.rollback()
            if new_logo: remove_images([new_logo])
            raise
        if old_logo and new_logo: remove_images([old_logo])
        flash('Ayarlar kaydedildi.', 'success')
        return redirect(url_for('admin.settings_page'))
    due = Issue.query.filter(Issue.created_at < now() - timedelta(days=settings.retention_days)).count()
    return render_template('settings.html', public_base_url=current_app.config['PUBLIC_BASE_URL'], ai_ready=bool(current_app.config['GEMINI_API_KEY']), due=due, audit=AuditLog.query.order_by(AuditLog.id.desc()).limit(30).all())

@bp.route('/kategoriler', methods=['GET', 'POST'])
def categories():
    if request.method == 'POST':
        category_id = request.form.get('id', type=int)
        item = db.get_or_404(IssueCategory, category_id) if category_id else IssueCategory()
        service = item.service if category_id else field('service', default='board')
        if service not in SERVICES: abort(400)
        item.service = service
        try:
            questions = validate_catalog(json.loads(field('questions', 2, 20000))) if service == 'board' else []
        except (ValueError, TypeError):
            flash('Sorular geçersiz. 3–7 soru ve her soruda Bilmiyorum dahil 2–6 seçenek kullanın.', 'error')
            return redirect(url_for('admin.categories'))
        item.name, item.questions = field('name', 3, 120), questions
        item.active = request.form.get('active') == 'yes'
        db.session.add(item)
        audit(f'Kategori/sorular güncellendi: {item.name}')
        try:
            db.session.commit()
            flash('Kategori kaydedildi.', 'success')
        except IntegrityError:
            db.session.rollback()
            flash('Bu kategori adı zaten mevcut.', 'error')
        return redirect(url_for('admin.categories'))
    return render_template('categories.html', categories=IssueCategory.query.order_by(IssueCategory.id).all(), default_questions=json.dumps(COMMON, ensure_ascii=False, indent=2))

@bp.get('/rapor.csv')
def export():
    def safe(value):
        text = str(value or '')
        return "'" + text if text.lstrip().startswith(('=', '+', '-', '@')) or text.startswith(('\t', '\r', '\n')) else text
    stream = io.StringIO()
    writer = csv.writer(stream, delimiter=';')
    writer.writerow(['Bildirim', 'Konu / Sınıf', 'Hesap', 'Öğretmen', 'Kategori', 'Durum', 'Öncelik', 'Tarih', 'Çözüm Tarihi', 'Açıklama'])
    for issue in filtered_issues().all():
        writer.writerow([safe(v) for v in [issue.number, issue.location_label, issue.account, issue.teacher, issue.category.name, STATUS[issue.status], PRIORITIES[issue.priority], current_app.jinja_env.filters['trdate'](issue.created_at), current_app.jinja_env.filters['trdate'](issue.resolved_at) if issue.resolved_at else '', issue.description]])
    audit('CSV raporu indirildi')
    db.session.commit()
    return Response('\ufeff' + stream.getvalue(), mimetype='text/csv; charset=utf-8', headers={'Content-Disposition': 'attachment; filename=ariza-raporu.csv'})

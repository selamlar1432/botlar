from flask import Blueprint, render_template, redirect, url_for, request, flash, session, abort
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from ..extensions import db, limiter
from ..models import AdminUser, AuditLog
from ..forms import LoginForm

bp = Blueprint('auth', __name__)
DUMMY = generate_password_hash('not-an-account-password')

@bp.route('/yonetici/giris', methods=['GET', 'POST'])
@limiter.limit('5 per minute; 30 per hour', methods=['POST'])
def login_page():
    form = LoginForm()
    if form.validate_on_submit():
        user = AdminUser.query.filter_by(username=form.username.data.strip()).first()
        valid = user.check_password(form.password.data) if user else check_password_hash(DUMMY, form.password.data)
        if user and valid:
            session.clear()
            login_user(user)
            session.permanent = True
            db.session.add(AuditLog(actor=user.username, action='Yönetici girişi'))
            db.session.commit()
            return redirect(url_for('auth.password' if user.must_change_password else 'admin.dashboard'))
        flash('Kullanıcı adı veya şifre hatalı.', 'error')
    return render_template('login.html', form=form)

@bp.post('/yonetici/cikis')
@login_required
def logout():
    logout_user()
    session.clear()
    return redirect(url_for('public.home'))

@bp.route('/yonetici/sifre', methods=['GET', 'POST'])
@login_required
@limiter.limit('10 per hour', methods=['POST'])
def password():
    if request.method == 'POST':
        old, new, confirm = (request.form.get(k, '') for k in ('old_password', 'new_password', 'confirm'))
        if not current_user.check_password(old): flash('Mevcut şifre hatalı.', 'error')
        elif not 12 <= len(new) <= 200 or new != confirm or new == old:
            flash('Yeni şifre 12–200 karakter olmalı, tekrarı eşleşmeli ve eskisinden farklı olmalıdır.', 'error')
        else:
            current_user.set_password(new)
            current_user.must_change_password = False
            db.session.add(AuditLog(actor=current_user.username, action='Şifre değiştirildi'))
            db.session.commit()
            logout_user()
            session.clear()
            flash('Şifreniz değiştirildi. Yeni şifrenizle giriş yapın.', 'success')
            return redirect(url_for('auth.login_page'))
    return render_template('password.html')

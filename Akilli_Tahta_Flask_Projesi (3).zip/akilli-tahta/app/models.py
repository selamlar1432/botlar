from datetime import datetime, timezone
import secrets
import hashlib
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from .extensions import db

def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)

STATUS = {'reported': 'Sorun Bildirildi', 'reviewing': 'İnceleniyor', 'resolved': 'Çözüldü', 'clear': 'Sorun Yok'}
SERVICES = {'board': 'Akıllı tahta', 'email': 'E-posta şifre sıfırlama', 'k12': 'K12 desteği', 'other': 'Diğer teknik destek'}
PRIORITIES = {'low': 'Düşük', 'normal': 'Normal', 'high': 'Yüksek', 'critical': 'Kritik'}

class AdminUser(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    must_change_password = db.Column(db.Boolean, default=True, nullable=False)
    def get_id(self):
        # A password change invalidates previously signed login sessions.
        return str(self.id) + ":" + hashlib.sha256(self.password_hash.encode()).hexdigest()[:24]
    def set_password(self, password):
        self.password_hash = generate_password_hash(password, method='scrypt')
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class GradeLevel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.Integer, unique=True, nullable=False)
    __table_args__ = (db.CheckConstraint('number >= 1 AND number <= 12'),)

class Classroom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    grade_id = db.Column(db.Integer, db.ForeignKey('grade_level.id'), nullable=False)
    branch = db.Column(db.String(20), nullable=False)
    active = db.Column(db.Boolean, default=True, nullable=False)
    grade = db.relationship('GradeLevel')
    issues = db.relationship('Issue', back_populates='classroom', lazy='selectin')
    __table_args__ = (db.UniqueConstraint('grade_id', 'branch'),)
    @property
    def name(self): return f'{self.grade.number}-{self.branch}'
    @property
    def state(self):
        if any(i.status == 'reported' for i in self.issues): return 'reported'
        if any(i.status == 'reviewing' for i in self.issues): return 'reviewing'
        return 'resolved' if self.issues else 'clear'
    @property
    def active_count(self): return sum(i.status != 'resolved' for i in self.issues)

class IssueCategory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    active = db.Column(db.Boolean, default=True, nullable=False)
    questions = db.Column(db.JSON, nullable=False)
    service = db.Column(db.String(20), default='board', server_default='board', nullable=False)

class Issue(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    classroom_id = db.Column(db.Integer, db.ForeignKey('classroom.id'), nullable=True, index=True)
    category_id = db.Column(db.Integer, db.ForeignKey('issue_category.id'), nullable=False)
    teacher = db.Column(db.String(120), nullable=False)
    contact = db.Column(db.String(200), default='')
    account = db.Column(db.String(200), default='', server_default='', nullable=False)
    service = db.Column(db.String(20), default='board', server_default='board', nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='reported', nullable=False, index=True)
    priority = db.Column(db.String(15), default='normal', nullable=False)
    created_at = db.Column(db.DateTime, default=now, nullable=False, index=True)
    resolved_at = db.Column(db.DateTime)
    archived = db.Column(db.Boolean, default=False, nullable=False)
    submission_key = db.Column(db.String(64), unique=True, nullable=False)
    classroom = db.relationship('Classroom', back_populates='issues')
    category = db.relationship('IssueCategory')
    answers = db.relationship('IssueAnswer', order_by='IssueAnswer.id')
    photos = db.relationship('IssuePhoto')
    history = db.relationship('IssueStatusHistory', order_by='IssueStatusHistory.created_at')
    notes = db.relationship('MaintenanceNote', order_by='MaintenanceNote.created_at')
    analysis = db.relationship('AIAnalysis', uselist=False)
    __table_args__ = (db.CheckConstraint("status IN ('reported','reviewing','resolved')", name="ck_issue_status"), db.CheckConstraint("priority IN ('low','normal','high','critical')", name="ck_issue_priority"))
    @property
    def location_label(self): return self.classroom.name if self.classroom else SERVICES.get(self.service, 'Teknik destek')
    @property
    def number(self): return f'AT-{self.created_at.year}-{self.id:06d}'

class IssueAnswer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    issue_id = db.Column(db.Integer, db.ForeignKey('issue.id'), nullable=False)
    question = db.Column(db.String(500), nullable=False)
    answer = db.Column(db.String(300), nullable=False)

class IssuePhoto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    issue_id = db.Column(db.Integer, db.ForeignKey('issue.id'), nullable=False)
    filename = db.Column(db.String(80), nullable=False, unique=True)

class IssueStatusHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    issue_id = db.Column(db.Integer, db.ForeignKey('issue.id'), nullable=False)
    status = db.Column(db.String(20), nullable=False)
    actor = db.Column(db.String(80), nullable=False)
    note = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=now, nullable=False)

class MaintenanceNote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    issue_id = db.Column(db.Integer, db.ForeignKey('issue.id'), nullable=False)
    text = db.Column(db.Text, nullable=False)
    actor = db.Column(db.String(80), nullable=False)
    created_at = db.Column(db.DateTime, default=now, nullable=False)

class AIAnalysis(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    issue_id = db.Column(db.Integer, db.ForeignKey('issue.id'), unique=True, nullable=False)
    data = db.Column(db.JSON, nullable=False)
    model = db.Column(db.String(100), nullable=False)

class AppSettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    institution = db.Column(db.String(120), default='Bilgi Koleji', nullable=False)
    logo = db.Column(db.String(80))
    ai_enabled = db.Column(db.Boolean, default=True, nullable=False)
    retention_days = db.Column(db.Integer, default=730, nullable=False)

class Draft(db.Model):
    id = db.Column(db.String(64), primary_key=True, default=lambda: secrets.token_urlsafe(32))
    owner = db.Column(db.String(64), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('issue_category.id'), nullable=False)
    catalog = db.Column(db.JSON, nullable=False)
    answers = db.Column(db.JSON, default=list, nullable=False)
    pending = db.Column(db.Integer)
    use_ai = db.Column(db.Boolean, default=False, nullable=False)
    complete = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=now, nullable=False)

class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    actor = db.Column(db.String(80), nullable=False)
    action = db.Column(db.String(500), nullable=False)
    created_at = db.Column(db.DateTime, default=now, nullable=False)

YES = ['Evet', 'Hayır', 'Bilmiyorum']
def q(text, options=None): return {'text': text, 'options': options or YES.copy()}
COMMON = [q('Bu sorun daha önce de yaşandı mı?'), q('Sorun ders boyunca devam ediyor mu?'), q('Ekranda bir uyarı yazısı görüyor musunuz?')]
SETS = {
'Akıllı tahta açılmıyor': [q('Tahtanın üzerinde yanan bir ışık var mı?'), q('Tahtadan herhangi bir ses geliyor mu?'), q('Ekranda kısa bir süre de olsa görüntü görünüyor mu?')],
'Ekran siyah kalıyor': [q('Açılış sırasında ne görüyorsunuz?', ['Bir marka veya Windows logosu', 'Tamamen siyah ekran', 'Sinyal yok yazısı', 'Görüntü geliyor, sonra kayboluyor', 'Bilmiyorum']), q('Ekranda fare işaretçisi görünüyor mu?'), q('Tahtanın üzerinde yanan bir ışık var mı?')],
'Sinyal yok yazıyor': [q('Bu yazı ne zaman görünüyor?', ['Tahta açılır açılmaz', 'Önce logo görünüyor, sonra bu yazı çıkıyor', 'Ders sırasında ortaya çıkıyor', 'Bilmiyorum']), q('Tahtanın üzerinde yanan bir ışık var mı?'), q('Bu yazıdan önce masaüstünü görebildiniz mi?')],
'Windows açılmıyor': [q('Ekranda ne görüyorsunuz?', ['Windows logosu', 'Hata yazısı', 'Siyah ekran', 'Bilmiyorum']), q('Ekrandaki yükleme işareti hareket ediyor mu?'), q('Tahta kendiliğinden tekrar açılıyor mu?')],
'Ekran dokunmatiği çalışmıyor': [q('Ekrandaki görüntü normal görünüyor mu?'), q('Dokunma ekranın herhangi bir yerinde çalışıyor mu?'), q('Dokunduğunuzda farklı bir yer seçiliyor mu?')],
'İnternet bağlantısı yok': [q('Açık olan internet sayfasında hata yazıyor mu?'), q('Aynı sınıfta başka bir cihazın internete bağlandığını gördünüz mü?'), q('Sorun yalnızca bir internet sitesinde mi oluyor?')],
'Ses gelmiyor': [q('Videonun görüntüsü oynuyor mu?'), q('Ekrandaki ses simgesinin üzerinde çarpı görüyor musunuz?'), q('Sorun farklı videolarda da oluyor mu?')],
'Görüntü bozuk veya titriyor': [q('Ekranda çizgiler görüyor musunuz?'), q('Görüntü sürekli titriyor mu?'), q('Bu durum açılış logosunda da var mı?')],
'Bilgisayar çok yavaş': [q('Yavaşlık tahta açılır açılmaz başlıyor mu?'), q('Ekrandaki fare işaretçisi hareket ediyor mu?'), q('Yalnızca belirli bir uygulama mı yavaş?')],
'Uygulamalar açılmıyor': [q('Bir hata mesajı görünüyor mu?'), q('Başka uygulamalar açılıyor mu?'), q('Uygulama açılıp hemen kapanıyor mu?')],
'Diğer': COMMON,
}

def validate_catalog(value):
    if not isinstance(value, list) or not 3 <= len(value) <= 7: raise ValueError('3–7 soru girilmelidir.')
    result = []
    for item in value:
        if not isinstance(item, dict): raise ValueError('Soru biçimi geçersiz.')
        text, options = item.get('text'), item.get('options')
        if not isinstance(text, str) or not 5 <= len(text.strip()) <= 500: raise ValueError('Soru metni 5–500 karakter olmalıdır.')
        if not isinstance(options, list) or not 2 <= len(options) <= 6 or any(not isinstance(x, str) or not 1 <= len(x) <= 300 for x in options): raise ValueError('Her soruda 2–6 geçerli seçenek olmalıdır.')
        if 'Bilmiyorum' not in options or len(set(options)) != len(options): raise ValueError('Her soruda Bilmiyorum seçeneği olmalı; seçenekler tekrarlanmamalıdır.')
        result.append({'text': text.strip(), 'options': options})
    return result

from ..extensions import db
from ..models import IssueStatusHistory, MaintenanceNote, now

def update_issue(issue, status, priority, note, actor):
    changed = issue.status != status
    if changed:
        issue.status = status
        issue.resolved_at = now() if status == 'resolved' else None
        if status != 'resolved': issue.archived = False
    if changed or issue.priority != priority:
        db.session.add(IssueStatusHistory(issue_id=issue.id, status=status, actor=actor, note=f'Öncelik: {priority}. {note}'))
    issue.priority = priority
    if note: db.session.add(MaintenanceNote(issue_id=issue.id, text=note, actor=actor))

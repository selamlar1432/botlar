import io
import secrets
import warnings
from pathlib import Path
from PIL import Image, ImageOps, UnidentifiedImageError
from flask import current_app

Image.MAX_IMAGE_PIXELS = 20_000_000

def save_image(file):
    if Path(file.filename or '').suffix.lower() not in {'.jpg', '.jpeg', '.png', '.webp'}:
        raise ValueError('Yalnız JPG, PNG veya WEBP fotoğraf yükleyin.')
    raw = file.read(5 * 1024 * 1024 + 1)
    if len(raw) > 5 * 1024 * 1024: raise ValueError('Her fotoğraf en fazla 5 MB olabilir.')
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(raw)) as test:
                if test.format not in {'JPEG', 'PNG', 'WEBP'}: raise ValueError('Fotoğraf biçimi geçersiz.')
                test.verify()
            with Image.open(io.BytesIO(raw)) as original:
                clean = ImageOps.exif_transpose(original).convert('RGB')
                clean.thumbnail((1920, 1920))
                # Rebuild pixels to ensure metadata is not copied.
                out = Image.new('RGB', clean.size)
                out.paste(clean)
                name = secrets.token_hex(24) + '.jpg'
                out.save(Path(current_app.config['UPLOAD_FOLDER']) / name, 'JPEG', quality=85)
                return name
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ValueError('Bu dosya geçerli ve güvenli bir fotoğraf değil.') from exc

def remove_images(names):
    for name in names:
        (Path(current_app.config['UPLOAD_FOLDER']) / name).unlink(missing_ok=True)

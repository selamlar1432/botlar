'use strict';
function selectPlatform(platform){for(const button of document.querySelectorAll('[data-platform]'))button.setAttribute('aria-pressed',String(button.dataset.platform===platform));document.querySelector('#install-android').hidden=platform!=='android';document.querySelector('#install-ios').hidden=platform!=='ios';}
document.querySelectorAll('[data-platform]').forEach(b=>b.addEventListener('click',()=>selectPlatform(b.dataset.platform)));
selectPlatform(/iPhone|iPad|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1)?'ios':'android');
if(window.matchMedia('(display-mode: standalone)').matches||navigator.standalone){document.querySelector('#installed-notice').hidden=false;document.querySelector('#install-app').hidden=true;}

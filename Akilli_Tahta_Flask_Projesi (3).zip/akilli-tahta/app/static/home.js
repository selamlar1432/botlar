'use strict';
const labels = {clear:'Sorun Yok',reported:'Sorun Bildirildi',reviewing:'İnceleniyor',resolved:'Çözüldü'};
let rooms = [];
const gradeFilter=document.querySelector('#grade-filter'), stateFilter=document.querySelector('#state-filter'), search=document.querySelector('#room-search');
function el(tag,text,cls){const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(cls)node.className=cls;return node;}
function renderRooms(){
  const grade=gradeFilter.value,state=stateFilter.value,term=search.value.toLocaleLowerCase('tr-TR');
  const selected=rooms.filter(r=>(!grade||String(r.grade)===grade)&&(!state||r.state===state)&&r.name.toLocaleLowerCase('tr-TR').includes(term));
  const container=document.querySelector('#rooms');container.replaceChildren();
  document.querySelector('#rooms-title').textContent=grade?`${grade}. Sınıf Şubeleri`:'Tüm Şubeler';
  document.querySelectorAll('[data-grade]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.grade===grade)));
  for(const r of selected){const card=el('article',undefined,'room-card');card.append(el('h3',r.name),el('span',labels[r.state],'badge '+r.state),el('p',`${r.active_count} aktif arıza`),el('small',`Son bildirim: ${r.last}`));const link=el('a','Sorun Bildir →');link.href='/bildir?classroom='+r.id;card.append(link);container.append(card);}
  if(!selected.length)container.append(el('div',rooms.length?'Bu filtrelere uygun şube bulunamadı.':'Şubeler henüz tanımlanmadı. Yönetici panelinden okulun şubelerini ekleyin.','empty'));
}
async function refresh(){
  try{const response=await fetch('/api/durum',{cache:'no-store'});if(!response.ok)throw Error();const data=await response.json();rooms=data.rooms;
    for(const [key,value] of Object.entries(data.stats))document.querySelectorAll(`[data-stat="${key}"]`).forEach(n=>n.textContent=value);
    for(let g=1;g<=12;g++){const items=rooms.filter(r=>r.grade===g),active=items.filter(r=>r.active_count>0).length;const node=document.querySelector('#grade-summary-'+g);if(node)node.textContent=items.length?`${items.length} şube · ${active ? active+' sınıfta sorun var' : 'Aktif arıza yok'}`:'Henüz şube eklenmedi';}
    renderRooms();document.querySelector('#sync-status').textContent='Son güncelleme: '+new Date().toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'});
  }catch(_){document.querySelector('#sync-status').textContent='Güncellenemedi. Görünen bilgiler güncel olmayabilir.';}
}
for(const node of [gradeFilter,stateFilter,search])node.addEventListener('input',renderRooms);
document.querySelectorAll('[data-grade]').forEach(b=>b.addEventListener('click',()=>{gradeFilter.value=gradeFilter.value===b.dataset.grade?'':b.dataset.grade;renderRooms();document.querySelector('#rooms-title').scrollIntoView({block:'nearest',behavior:'smooth'});}));
refresh();setInterval(()=>{if(!document.hidden)refresh();},30000);

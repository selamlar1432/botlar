'use strict';
window.csrfToken = () => document.querySelector('meta[name="csrf-token"]').content;
window.api = async (url, payload) => {
  const response = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json','X-CSRFToken':csrfToken(),'X-Requested-With':'XMLHttpRequest'}, body:JSON.stringify(payload)});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'İşlem tamamlanamadı. Lütfen yeniden deneyin.');
  return data;
};
if ('serviceWorker' in navigator && window.isSecureContext) navigator.serviceWorker.register('/sw.js').catch(() => {});
let installPrompt;
window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault(); installPrompt=event;
  const button=document.querySelector('#install-app');
  if(button)button.hidden=false;
});
document.querySelector('#install-app')?.addEventListener('click',async()=>{
  if(!installPrompt)return;
  const button=document.querySelector('#install-app');button.disabled=true;
  try{await installPrompt.prompt();const choice=await installPrompt.userChoice;document.querySelector('#install-feedback').textContent=choice.outcome==='accepted'?'Yükleme isteği onaylandı. Ana ekranınızı kontrol edin.':'Dilerseniz aşağıdaki adımlarla daha sonra ekleyebilirsiniz.';}
  finally{installPrompt=null;button.hidden=true;button.disabled=false;}
});
window.addEventListener('appinstalled',()=>{const text=document.querySelector('#install-feedback');if(text)text.textContent='Ana ekranınıza eklendi.';const button=document.querySelector('#install-app');if(button)button.hidden=true;});
const tour = document.querySelector('#tour');
const tourPages = [
 ['Destek konusunu seçin.', 'Akıllı tahta, e-posta şifre sıfırlama, K12 veya diğer teknik destek seçeneklerinden ihtiyacınıza dokunun.'],
 ['Kısaca anlatın.', 'Adınızı ve sorununuzu yazın. Akıllı tahta için sınıfınızı seçin ve kolay soruları yanıtlayın. Emin değilseniz Bilmiyorum seçebilirsiniz.'],
 ['Gönderin, durumunu takip edin.', 'Bilgileri kontrol edip Talebi Gönder düğmesine dokunun. Verilen bildirim numarasını saklayın; Talebim bölümünde durumunu öğrenebilirsiniz.'],
 ['Telefonunuza da ekleyebilirsiniz.', 'Ana sayfadaki Telefonunuzdan tek dokunuşla ulaşın bölümünü açın. Android ve iPhone için adım adım ekleme rehberini göreceksiniz.']
];
let tourIndex = 0;
function showTourPage() {
  document.querySelector('#tour-count').textContent = `KULLANIM REHBERİ · ${tourIndex + 1} / 4`;
  document.querySelector('#tour-visual').textContent=String(tourIndex+1);
  document.querySelector('#tour-title').textContent = tourPages[tourIndex][0];
  document.querySelector('#tour-text').textContent = tourPages[tourIndex][1];
  document.querySelector('#tour-back').disabled = tourIndex === 0;
  document.querySelector('#tour-next').textContent = tourIndex === 3 ? 'Tamamla' : 'İleri';
}
function finishTour() { try {localStorage.setItem('bilgi-tour-v2','seen');} catch (_) {} tour.close(); }
function startTour() {tourIndex=0; showTourPage(); tour.showModal();}
document.querySelectorAll('[data-tour]').forEach(button => button.addEventListener('click',startTour));
document.querySelector('#tour-back').addEventListener('click',()=>{if(tourIndex>0) tourIndex--;showTourPage();});
document.querySelector('#tour-next').addEventListener('click',()=>{if(tourIndex===3) finishTour();else {tourIndex++;showTourPage();}});
document.querySelector('#tour-skip').addEventListener('click',finishTour);
tour.addEventListener('cancel',()=>{try{localStorage.setItem('bilgi-tour-v2','seen');}catch(_){}});
if(location.pathname === '/') {try {if(!localStorage.getItem('bilgi-tour-v2')) startTour();}catch(_){}}

'use strict';
const form=document.querySelector('#report-form'),errorBox=document.querySelector('#form-error');
let step=0,draft=null,categoryAtStart=null,busy=false,previewURLs=[];
function error(message){errorBox.textContent=message;errorBox.hidden=!message;if(message)errorBox.scrollIntoView({block:'nearest'});}
function setBusy(value){busy=value;for(const b of form.querySelectorAll('button'))b.disabled=value;}
function validateStep(){for(const node of document.querySelector(`[data-step="${step}"]`).querySelectorAll('input,select,textarea'))if(!node.checkValidity()){node.reportValidity();return false;}return true;}
function showStep(){
  document.querySelectorAll('[data-step]').forEach(s=>s.hidden=Number(s.dataset.step)!==step);
  document.querySelectorAll('[data-step-ind]').forEach(n=>{n.classList.toggle('current',Number(n.dataset.stepInd)===step);n.classList.toggle('done',Number(n.dataset.stepInd)<step);});
  document.querySelector('#step-caption').textContent=`ADIM ${step+1} / 5`;
  document.querySelector('#step-progress').value=step+1;
  document.querySelector('#previous').hidden=step===0;
  document.querySelector('#next').hidden=step===4;
  document.querySelector('#send').hidden=step!==4;
  if(step===4)renderReview();
}
function duplicateNotice(){const select=document.querySelector('#classroom'),count=Number(select.selectedOptions[0]?.dataset.count||0);document.querySelector('#duplicate-notice').hidden=!count;}
document.querySelector('#classroom').addEventListener('change',()=>{form.elements.different.checked=false;duplicateNotice();});
async function startQuestions(){
  const category=Number(form.elements.category.value);
  if(draft&&categoryAtStart===category)return;
  draft=await api('/api/sorular/basla',{category,ai:document.querySelector('#use-ai').checked});categoryAtStart=category;
  document.querySelector('#draft-id').value=draft.id;renderQuestion();
}
function renderQuestion(){
  const box=document.querySelector('#question-box');box.replaceChildren();
  document.querySelector('#question-status').textContent=draft.ai?'Cevaplarınıza göre sorular seçiliyor.':'Arıza bildiriminize standart sorularla devam edebilirsiniz.';
  document.querySelector('#question-back').hidden=draft.count===0;
  document.querySelector('#disable-ai').hidden=!draft.ai;
  if(draft.complete){const p=document.createElement('p');p.className='notice success';p.textContent='Sorular tamamlandı. Fotoğraf adımına geçebilirsiniz.';box.append(p);return;}
  const title=document.createElement('h3');title.className='question-title';title.textContent=`${draft.count+1} / 3 · ${draft.question.text}`;box.append(title);
  draft.question.options.forEach((option,index)=>{const label=document.createElement('label');label.className='question-option';const input=document.createElement('input');input.type='radio';input.name='question-answer';input.value=option;input.id='answer-'+index;label.append(input,document.createTextNode(option));box.append(label);});
}
document.querySelector('#next').addEventListener('click',async()=>{
  if(busy||!validateStep())return;error('');setBusy(true);
  try{
    if(step===0&&!document.querySelector('#duplicate-notice').hidden&&!form.elements.different.checked)throw Error('Bu sınıfta mevcut bildirim var. Farklı bir sorun olduğunu onaylayın.');
    if(step===1){await startQuestions();renderQuestion();}
    if(step===2&&!draft.complete){const selected=form.querySelector('input[name="question-answer"]:checked');if(!selected)throw Error('Bir cevap seçin. Emin değilseniz Bilmiyorum seçeneğini kullanın.');draft=await api('/api/sorular/'+draft.id,{answer:selected.value});renderQuestion();if(!draft.complete)return;}
    if(step===3&&!validatePhotos())return;
    step++;showStep();
  }catch(exc){error(exc.message||'Bağlantı kurulamadı. Lütfen tekrar deneyin.');}finally{setBusy(false);}
});
document.querySelector('#previous').addEventListener('click',()=>{if(!busy&&step>0){step--;error('');showStep();if(step===2)renderQuestion();}});
document.querySelector('#question-back').addEventListener('click',async()=>{setBusy(true);try{draft=await api('/api/sorular/'+draft.id,{back:true});renderQuestion();}catch(exc){error(exc.message);}finally{setBusy(false);}});
document.querySelector('#disable-ai').addEventListener('click',async()=>{setBusy(true);try{draft=await api('/api/sorular/'+draft.id,{disable_ai:true});document.querySelector('#use-ai').checked=false;renderQuestion();}catch(exc){error(exc.message);}finally{setBusy(false);}});
document.querySelector('#use-ai').addEventListener('change',()=>{draft=null;document.querySelector('#draft-id').value='';});
function validatePhotos(){const files=Array.from(form.elements.photos.files);if(files.length>3){error('En fazla 3 fotoğraf seçebilirsiniz.');return false;}if(files.some(f=>f.size>5*1024*1024||!['image/jpeg','image/png','image/webp'].includes(f.type))){error('Fotoğraflar JPG, PNG veya WEBP biçiminde ve en fazla 5 MB olmalıdır.');return false;}return true;}
function previews(){previewURLs.forEach(URL.revokeObjectURL);previewURLs=[];const box=document.querySelector('#photo-preview');box.replaceChildren();if(!validatePhotos())return;error('');for(const file of form.elements.photos.files){const figure=document.createElement('figure'),image=document.createElement('img'),caption=document.createElement('figcaption');const url=URL.createObjectURL(file);previewURLs.push(url);image.src=url;image.alt='Yüklenecek fotoğraf';caption.textContent=file.name;figure.append(image,caption);box.append(figure);}}
form.elements.photos.addEventListener('change',previews);
document.querySelector('#clear-photos').addEventListener('click',()=>{form.elements.photos.value='';previews();});
function renderReview(){const box=document.querySelector('#review');box.replaceChildren();const values=[['Sınıf',form.elements.classroom.selectedOptions[0].textContent],['Öğretmen',form.elements.teacher.value],['Kategori',form.elements.category.selectedOptions[0].textContent],['Açıklama',form.elements.description.value],['İletişim',form.elements.contact.value||'Belirtilmedi'],['Fotoğraf sayısı',String(form.elements.photos.files.length)]];for(const a of draft?.answers||[])values.push([a.question,a.answer]);for(const [title,text] of values){const row=document.createElement('div');row.className='answer';const h=document.createElement('h3'),p=document.createElement('p');h.textContent=title;p.textContent=text;row.append(h,p);box.append(row);}}
form.addEventListener('submit',event=>{
  event.preventDefault();if(step!==4||busy)return;error('');setBusy(true);
  const xhr=new XMLHttpRequest();xhr.open('POST','/api/bildirim');xhr.timeout=60000;xhr.setRequestHeader('X-CSRFToken',csrfToken());xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  const progress=document.querySelector('#upload-progress'),status=document.querySelector('#upload-status');progress.hidden=false;status.textContent='Bildirim gönderiliyor…';
  xhr.upload.addEventListener('progress',e=>{if(e.lengthComputable){progress.value=e.loaded/e.total*100;if(progress.value===100)status.textContent='Bilgiler kaydediliyor. Lütfen bekleyin…';}});
  xhr.onload=()=>{let data;try{data=JSON.parse(xhr.responseText);}catch(_){error('Sunucu yanıtı alınamadı. Tekrar deneyebilirsiniz.');setBusy(false);return;}if(xhr.status>=200&&xhr.status<300){location.assign(data.url);return;}error(data.error||'Gönderilemedi.');status.textContent='Bildirim tamamlanmadı.';setBusy(false);if(data.duplicate){step=0;document.querySelector('#duplicate-notice').hidden=false;showStep();}};
  const networkError=()=>{error('Sonuç doğrulanamadı. Bağlantınızı kontrol edip tekrar gönderin; aynı bildirim ikinci kez oluşturulmaz.');status.textContent='Gönderim sonucu alınamadı.';setBusy(false);};xhr.onerror=networkError;xhr.ontimeout=networkError;xhr.send(new FormData(form));
});
duplicateNotice();showStep();

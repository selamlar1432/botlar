import pytest
from app import create_app
from app.extensions import db
from app.models import Classroom, GradeLevel
@pytest.fixture
def app(tmp_path):
 a=create_app({'TESTING':True,'SECRET_KEY':'test-secret-key-'*4,'SQLALCHEMY_DATABASE_URI':'sqlite:///'+str(tmp_path/'test.db'),'UPLOAD_FOLDER':str(tmp_path/'uploads'),'WTF_CSRF_ENABLED':False,'RATELIMIT_ENABLED':False,'SESSION_COOKIE_SECURE':False,'GEMINI_API_KEY':''})
 with a.app_context():
  db.create_all()
  result=a.test_cli_runner().invoke(args=['seed']); assert result.exit_code==0,result.output
  db.session.add_all([Classroom(grade_id=GradeLevel.query.filter_by(number=n).first().id,branch='A') for n in (5,6)]); db.session.commit()
 yield a
 with a.app_context(): db.session.remove(); db.drop_all()
@pytest.fixture
def client(app): return app.test_client()
def draft(c,ai=False):
 c.get('/bildir');r=c.post('/api/sorular/basla',json={'category':1,'ai':ai});assert r.status_code==200,r.data;d=r.json
 for _ in range(3): d=c.post('/api/sorular/'+d['id'],json={'answer':'Bilmiyorum'}).json
 assert d['complete'];return d
def submit(c,ai=False,**kwargs):
 d=draft(c,ai)
 with c.session_transaction() as s:key=s['submission_key']
 data={'submission_key':key,'draft_id':d['id'],'classroom':'1','category':'1','teacher':'Test Öğretmen','description':'Ekran görüntüsü yok.','different':'yes'};data.update(kwargs)
 return c.post('/api/bildirim',data=data)
def admin(c):
 assert c.post('/yonetici/giris',data={'username':'emre','password':'akilitahtalar123456'}).status_code==302
 c.post('/yonetici/sifre',data={'old_password':'akilitahtalar123456','new_password':'YeniGuvenliSifre123!','confirm':'YeniGuvenliSifre123!'})
 assert c.post('/yonetici/giris',data={'username':'emre','password':'YeniGuvenliSifre123!'}).status_code==302

from pathlib import Path
import sqlite3
from flask_migrate import upgrade
from app import create_app
from app.extensions import db
from app.models import Issue, IssueCategory

def test_v1_database_upgrade_preserves_history(tmp_path):
    path=tmp_path/'old.db'
    app=create_app(dict(TESTING=True,SECRET_KEY='x'*40,SQLALCHEMY_DATABASE_URI='sqlite:///'+str(path),UPLOAD_FOLDER=str(tmp_path/'uploads'),RATELIMIT_ENABLED=False))
    with app.app_context():
        upgrade(revision='ebd1e50d84d1')
    con=sqlite3.connect(path)
    con.executescript("""
    INSERT INTO grade_level VALUES(1,5);
    INSERT INTO classroom VALUES(1,1,'A',1);
    INSERT INTO issue_category VALUES(1,'Eski kategori',1,'[]');
    INSERT INTO issue(id,classroom_id,category_id,teacher,contact,description,status,priority,created_at,archived,submission_key)
      VALUES(7,1,1,'Eski öğretmen','','Eski arıza','reported','normal','2026-10-23 09:00:00',0,'old-submit-key');
    INSERT INTO issue_answer VALUES(1,7,'Işık var mı?','Evet');
    INSERT INTO issue_photo VALUES(1,7,'old-photo.jpg');
    INSERT INTO issue_status_history VALUES(1,7,'reported','Öğretmen','Eski not','2026-10-23 09:00:00');
    INSERT INTO maintenance_note VALUES(1,7,'Eski müdahale','emre','2026-10-23 10:00:00');
    """);con.commit();con.close()
    with app.app_context():
        upgrade()
        issue=db.session.get(Issue,7)
        assert issue.teacher=='Eski öğretmen' and issue.service=='board' and issue.account==''
        assert issue.classroom.name=='5-A' and issue.answers[0].answer=='Evet'
        assert issue.photos[0].filename=='old-photo.jpg' and issue.notes[0].text=='Eski müdahale'
        assert len(issue.history)==1
        assert app.test_cli_runner().invoke(args=['seed']).exit_code==0
        assert IssueCategory.query.filter_by(service='email').count()==1
        db.session.remove()
    con=sqlite3.connect(path)
    assert con.execute('PRAGMA foreign_key_check').fetchall()==[]
    schema=con.execute("SELECT sql FROM sqlite_master WHERE name='issue'").fetchone()[0]
    assert 'ck_issue_status' in schema and 'ck_issue_priority' in schema
    try:
        con.execute("UPDATE issue SET status='invalid' WHERE id=7")
    except sqlite3.IntegrityError:pass
    else:raise AssertionError('Status constraint lost during upgrade')
    con.close()

import io,re
from pathlib import Path
import pytest
from PIL import Image
from app.extensions import db
from app.models import Issue,Classroom,AdminUser,GradeLevel,AIAnalysis,IssuePhoto,IssueCategory,Draft
from app.services import gemini
from conftest import draft,submit,admin

def test_seed(app):
 assert app.test_cli_runner().invoke(args=['seed']).exit_code==0
 with app.app_context():
  assert GradeLevel.query.count()==12 and AdminUser.query.count()==1 and IssueCategory.query.count()==17
  assert AdminUser.query.one().password_hash.startswith('scrypt:')
def test_public_counts(client):
 assert client.get('/').status_code==200
 assert client.get('/api/durum').json['stats']==dict(total=2,problem=0,reviewing=0,resolved=0)
 submit(client);r=client.get('/api/durum');assert r.json['stats']['problem']==1 and b'Test' not in r.data

def test_submission(app,client):
 r=submit(client,classroom='2');assert r.status_code==201,r.data
 with app.app_context():
  i=Issue.query.one();assert i.classroom_id==2 and len(i.answers)==3 and i.analysis is None
 assert client.get(r.json['url']).status_code==200

@pytest.mark.parametrize('path',['/yonetici/','/yonetici/siniflar','/yonetici/ayarlar','/yonetici/kategoriler','/yonetici/fotograf/1','/yonetici/rapor.csv','/yonetici/sinif/1/qr.png'])
def test_admin_protection(client,path):assert client.get(path).status_code==302

def test_first_password_required(client,app):
 client.post('/yonetici/giris',data={'username':'emre','password':'akilitahtalar123456'})
 assert client.get('/yonetici/').location.endswith('/yonetici/sifre')
 assert client.get('/yonetici/rapor.csv').location.endswith('/yonetici/sifre')
 client.post('/yonetici/sifre',data={'old_password':'wrong','new_password':'New1234567890','confirm':'New1234567890'})
 with app.app_context():assert AdminUser.query.one().must_change_password

def test_multi_issue_state_and_reopen(app,client):
 submit(client);client.post('/yeni-bildirim');submit(client);admin(client)
 def change(i,status,note='Müdahale yapıldı.'):
  return client.post(f'/yonetici/bildirim/{i}',data={'status':status,'priority':'normal','note':note})
 assert change(1,'resolved').status_code==302
 assert client.get('/api/durum').json['rooms'][0]['state']=='reported'
 change(2,'reviewing');assert client.get('/api/durum').json['rooms'][0]['state']=='reviewing'
 change(2,'resolved');assert client.get('/api/durum').json['rooms'][0]['state']=='resolved'
 assert client.get('/api/durum').json['rooms'][1]['state']=='clear'
 client.post('/yonetici/bildirim/1/arsiv');change(1,'reported')
 with app.app_context():
  i=db.session.get(Issue,1);assert not i.archived and i.resolved_at is None and len(i.history)==3

def test_resolve_requires_note(client,app):
 submit(client);admin(client);client.post('/yonetici/bildirim/1',data={'status':'resolved','priority':'normal','note':''})
 with app.app_context():assert db.session.get(Issue,1).status=='reported'

def test_idempotent(client,app):
 d=draft(client)
 with client.session_transaction() as sess:key=sess['submission_key']
 data=dict(submission_key=key,draft_id=d['id'],classroom='1',category='1',teacher='Test Kişi',description='Ekran açılmıyor.')
 r=client.post('/api/bildirim',data=data);r2=client.post('/api/bildirim',data=data);assert r.json['number']==r2.json['number']
 with app.app_context():assert Issue.query.count()==1

def test_duplicate_warning(client,app):
 submit(client);client.post('/yeni-bildirim');assert submit(client,different='').status_code==409
 with app.app_context():assert Issue.query.count()==1

def image_file():
 out=io.BytesIO();im=Image.new('RGB',(80,80),'red');exif=Image.Exif();exif[270]='Private metadata';im.save(out,format='JPEG',exif=exif);out.seek(0);return out

def test_photo(app,client):
 assert submit(client,photos=(image_file(),'photo.jpg')).status_code==201
 with app.app_context():
  p=IssuePhoto.query.one();filename=p.filename
  with Image.open(Path(app.config['UPLOAD_FOLDER'])/filename) as im:assert not im.getexif()
 assert client.get('/static/'+filename).status_code==404
 assert client.get('/yonetici/fotograf/1').status_code==302
 admin(client);r=client.get('/yonetici/fotograf/1');assert r.status_code==200 and r.headers['Cache-Control']=='no-store'

@pytest.mark.parametrize('name,data',[('x.jpg',b'<script>x</script>'),('x.svg',b'<svg/>'),('x.png',b'bad')])
def test_bad_photo(app,client,name,data):
 assert submit(client,photos=(io.BytesIO(data),name)).status_code==400
 with app.app_context():assert Issue.query.count()==0

def test_photo_count(client):assert submit(client,photos=[(image_file(),str(i)+'.jpg') for i in range(4)]).status_code==400

def test_ai_failure(app,client,monkeypatch):
 app.config['GEMINI_API_KEY']='test'
 def fail(*a,**k):raise TimeoutError()
 monkeypatch.setattr(gemini,'generate',fail)
 assert submit(client,ai=True).status_code==201
 with app.app_context():assert AIAnalysis.query.count()==0 and not Draft.query.one().use_ai

def test_ai_success_privacy(app,client,monkeypatch):
 app.config['GEMINI_API_KEY']='test';prompts=[]
 def generate(prompt,schema):
  prompts.append(prompt)
  if 'index' in schema['properties']:return {'index':schema['properties']['index']['enum'][-1]}
  return dict(symptoms=['Işık görünmüyor.'],possible_causes=['Güç sorunu olabilir.'],technical_checks=['Uzman kontrolü.'],confidence='Düşük')
 monkeypatch.setattr(gemini,'generate',generate)
 assert submit(client,ai=True,teacher='PRIVATE_PERSON',contact='PRIVATE_CONTACT',description='PRIVATE_DESCRIPTION').status_code==201
 assert all('PRIVATE_' not in p for p in prompts)
 with app.app_context():assert AIAnalysis.query.count()==1

def test_invalid_ai_fallback(app,client,monkeypatch):
 app.config['GEMINI_API_KEY']='test';monkeypatch.setattr(gemini,'generate',lambda *a:{'index':999})
 assert submit(client,ai=True).status_code==201
 with app.app_context():assert AIAnalysis.query.count()==0

def test_analysis_failure_does_not_lose_issue(app,client,monkeypatch):
 app.config['GEMINI_API_KEY']='test'
 def generate(prompt,schema):
  if 'index' in schema['properties']:return {'index':schema['properties']['index']['enum'][0]}
  raise ValueError()
 monkeypatch.setattr(gemini,'generate',generate)
 assert submit(client,ai=True).status_code==201
 with app.app_context():assert Issue.query.count()==1 and AIAnalysis.query.count()==0

def test_skip_ai(app,client,monkeypatch):
 app.config['GEMINI_API_KEY']='test'
 def fail(*a):pytest.fail('AI should not be called')
 monkeypatch.setattr(gemini,'generate',fail);assert submit(client,ai=False).status_code==201

def test_answer_validation_and_ownership(app,client):
 client.get('/bildir');d=client.post('/api/sorular/basla',json={'category':1,'ai':False}).json
 assert client.post('/api/sorular/'+d['id'],json={'answer':'invalid'}).status_code==400
 assert app.test_client().post('/api/sorular/'+d['id'],json={'answer':'Bilmiyorum'}).status_code==400

def test_back_question(client):
 d=draft(client);b=client.post('/api/sorular/'+d['id'],json={'back':True}).json
 assert b['count']==2 and not b['complete']
 assert client.post('/api/sorular/'+d['id'],json={'answer':'Bilmiyorum'}).json['complete']

def test_tracking_privacy(client):
 r=submit(client,teacher='PRIVATE_PERSON',description='PRIVATE_DESCRIPTION');page=client.get('/takip?q='+r.json['number'])
 assert page.status_code==200 and b'PRIVATE' not in page.data

def test_admin_pages(client):
 submit(client);admin(client)
 for p in ['/yonetici/','/yonetici/bildirim/1','/yonetici/siniflar','/yonetici/sinif/1','/yonetici/ayarlar','/yonetici/kategoriler','/yonetici/sifre']:
  assert client.get(p).status_code==200,p

def test_classrooms(app,client):
 submit(client);admin(client)
 with app.app_context():g=db.session.get(Classroom,1).grade_id
 client.post('/yonetici/siniflar',data={'id':'1','grade':g,'branch':'A'})
 with app.app_context():assert db.session.get(Classroom,1).active
 for _ in range(2):client.post('/yonetici/siniflar',data={'grade':g,'branch':'B','active':'yes'})
 with app.app_context():assert Classroom.query.count()==3

def test_csv(client):
 submit(client,teacher='=HYPERLINK("bad")');admin(client)
 text=client.get('/yonetici/rapor.csv').data.decode('utf-8-sig');assert "'=HYPERLINK" in text and 'AT-' in text
 assert b'AT-' not in client.get('/yonetici/rapor.csv?status=resolved').data

def test_csrf(app,client):
 app.config['WTF_CSRF_ENABLED']=True
 assert client.post('/yonetici/giris',data={'username':'emre','password':'akilitahtalar123456'}).status_code==400
 assert client.post('/api/sorular/basla',json={'category':1}).status_code==400
 token=re.search(r'name="csrf-token" content="([^"]+)"',client.get('/bildir').data.decode()).group(1)
 assert client.post('/api/sorular/basla',json={'category':1,'ai':False},headers={'X-CSRFToken':token}).status_code==200

def test_pwa_headers(client):
 assert len(client.get('/manifest.webmanifest').json['icons'])==2
 for p in ['/offline','/sw.js','/static/icon-192.png','/static/icon-512.png','/yardim','/gizlilik']:assert client.get(p).status_code==200
 h=client.get('/').headers;assert h['X-Frame-Options']=='DENY' and "object-src 'none'" in h['Content-Security-Policy'] and h['Cache-Control']=='no-store'

def test_xss(client):
 submit(client,description='<script>alert(1)</script>');admin(client);text=client.get('/yonetici/bildirim/1').data.decode()
 assert '<script>alert(1)</script>' not in text and '&lt;script&gt;' in text

def test_qr(client):admin(client);assert client.get('/yonetici/sinif/1/qr.png').data.startswith(b'\x89PNG')

def test_category_validation(client,app):
 admin(client);client.post('/yonetici/kategoriler',data={'name':'Yeni kategori','questions':'[]','active':'yes'})
 with app.app_context():assert IssueCategory.query.count()==17

def test_inactive_classroom(app,client):
 with app.app_context():db.session.get(Classroom,1).active=False;db.session.commit()
 assert submit(client).status_code==400


def test_new_report_from_home_gets_new_key(client,app):
 assert submit(client).status_code==201
 assert submit(client).status_code==201
 with app.app_context():assert Issue.query.count()==2

def test_password_change_revokes_other_sessions(app,client):
 admin(client)
 other=app.test_client()
 other.post('/yonetici/giris',data={'username':'emre','password':'YeniGuvenliSifre123!'})
 assert other.get('/yonetici/').status_code==200
 client.post('/yonetici/sifre',data={'old_password':'YeniGuvenliSifre123!','new_password':'AnotherPassword987!','confirm':'AnotherPassword987!'})
 assert other.get('/yonetici/').status_code==302

def test_admin_class_name_search(client):
 submit(client);admin(client)
 assert b'AT-' in client.get('/yonetici/rapor.csv?q=5-A').data
 assert b'AT-' not in client.get('/yonetici/rapor.csv?q=6-A').data

def test_photo_failure_cleans_partial_uploads(app,client):
 assert submit(client,photos=[(image_file(),'ok.jpg'),(io.BytesIO(b'bad'),'bad.jpg')]).status_code==400
 assert not list(Path(app.config['UPLOAD_FOLDER']).iterdir())

def test_login_rate_limit(tmp_path):
 from app import create_app
 a=create_app({'TESTING':True,'SECRET_KEY':'test-limit-key-'*4,'SQLALCHEMY_DATABASE_URI':'sqlite:///'+str(tmp_path/'limits.db'),'UPLOAD_FOLDER':str(tmp_path/'uploads'),'WTF_CSRF_ENABLED':False,'RATELIMIT_ENABLED':True,'RATELIMIT_STORAGE_URI':'memory://'})
 with a.app_context():
  db.create_all();a.test_cli_runner().invoke(args=['seed'])
 c=a.test_client()
 for _ in range(5):assert c.post('/yonetici/giris',data={'username':'missing','password':'bad'}).status_code==200
 assert c.post('/yonetici/giris',data={'username':'missing','password':'bad'}).status_code==429
 with a.app_context():db.session.remove();db.drop_all()

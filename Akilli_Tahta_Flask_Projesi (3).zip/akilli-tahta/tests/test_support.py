import io
from app.extensions import db
from app.models import Issue, IssueCategory, Classroom, AIAnalysis
from conftest import admin
import pytest

def support(client, app, service='email', **kwargs):
    client.get('/bildir?service='+service)
    with app.app_context():category=IssueCategory.query.filter_by(service=service).first().id
    with client.session_transaction() as session:key=session['submission_key']
    data=dict(service=service,category=category,submission_key=key,teacher='Öğretmen Test',description='Hesaba giriş yapamıyorum.',account='PRIVATE@example.com',contact='PRIVATE_CONTACT')
    data.update(kwargs)
    return client.post('/api/bildirim',data=data)

@pytest.mark.parametrize('service',['email','k12','other'])
def test_support_roundtrip(app,client,service):
    r=support(client,app,service)
    assert r.status_code==201,r.data
    assert client.get(r.json['url']).status_code==200
    with app.app_context():
        i=Issue.query.one()
        assert i.classroom_id is None and i.service==service and i.account=='PRIVATE@example.com'
        assert not i.answers and not i.analysis
        assert Classroom.query.first().state=='clear'
    tracking=client.get('/takip?q='+r.json['number'])
    assert b'PRIVATE' not in tracking.data
    assert b'PRIVATE' not in client.get('/api/durum').data
    admin(client)
    assert b'PRIVATE@example.com' in client.get('/yonetici/bildirim/1').data
    assert client.get('/yonetici/').status_code==200
    assert 'PRIVATE@example.com' in client.get('/yonetici/rapor.csv?service='+service).text
    assert b'AT-' not in client.get('/yonetici/rapor.csv?service=board').data
    assert client.post('/yonetici/bildirim/1',data=dict(status='resolved',priority='normal',note='Kimlik doğrulanıp destek sağlandı.')).status_code==302
    assert client.get('/api/durum').json['stats']['resolved']==0

def test_email_validation(app,client):
    assert support(client,app,account='not-an-email').status_code==400
    with app.app_context():assert Issue.query.count()==0

def test_k12_account_required(app,client):
    assert support(client,app,'k12',account='').status_code==400

def test_service_category_mismatch(app,client):
    assert support(client,app,'email',category=1).status_code==400

def test_no_school_setup_needed_for_account_support(app,client):
    with app.app_context():Classroom.query.delete();db.session.commit()
    assert support(client,app).status_code==201

def test_nonboard_questions_disallowed(app,client):
    with app.app_context():category=IssueCategory.query.filter_by(service='email').first().id
    assert client.post('/api/sorular/basla',json=dict(category=category,ai=True)).status_code==400

def test_account_data_never_calls_ai(app,client,monkeypatch):
    from app.services import gemini
    app.config['GEMINI_API_KEY']='test'
    def fail(*args):pytest.fail('Account requests must not invoke Gemini')
    monkeypatch.setattr(gemini,'generate',fail)
    assert support(client,app,'k12').status_code==201

@pytest.mark.parametrize('path',['/','/siniflar','/telefonuma-ekle','/yardim','/bildir?service=email','/bildir?service=k12','/bildir?service=other','/kurum-logo','/healthz'])
def test_new_pages(client,path):assert client.get(path).status_code==200

def test_home_simple_brand(client):
    page=client.get('/').text
    assert 'bilgi' in page.lower() and 'school-logo' in page
    assert 'Toplam Sınıf Sayısı' not in page and 'Çözülen Arızalar' not in page
    for service in ['board','email','k12','other']:assert '?service='+service in page
    assert '/telefonuma-ekle' in page

def test_production_localhost_rejected(tmp_path):
    from app import create_app
    with pytest.raises(RuntimeError,match='PUBLIC_BASE_URL'):
        create_app(dict(SECRET_KEY='x'*40,APP_ENV='production',RATELIMIT_STORAGE_URI='redis://redis:6379',PUBLIC_BASE_URL='http://127.0.0.1:5000'))

def test_qr_uses_public_domain(client,app,monkeypatch):
    import qrcode
    app.config['PUBLIC_BASE_URL']='https://destek.school.test'
    captured=[];original=qrcode.make
    def capture(value):captured.append(value);return original(value)
    monkeypatch.setattr(qrcode,'make',capture)
    admin(client)
    assert client.get('/yonetici/sinif/1/qr.png').status_code==200
    assert captured==['https://destek.school.test/bildir?classroom=1']

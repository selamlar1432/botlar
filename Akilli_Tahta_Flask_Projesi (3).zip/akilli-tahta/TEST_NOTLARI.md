# Doğrulama notları

Tarih: 26 Ekim 2026

## Tamamlanan kontroller

- Python 3.12.14 üzerinde bağımlılıklar kuruldu; teslimattaki `requirements.txt` kullanılan sürümleri sabitler.
- `python -m pytest -q`: **64 passed**.
- `flask --app run db init`, `db migrate`, `db upgrade`, `seed`: çalıştırıldı; ilk migration pakete eklendi. Son kullanıcı yalnız `db upgrade` ve `seed` çalıştırmalıdır.
- `flask --app run db check`: **No new upgrade operations detected**.
- Python compileall: başarılı.
- `node --check`: app.js, home.js, report.js, support.js, install.js, sw.js sözdizimi kontrolleri başarılı.
- Flask test istemcisiyle ana sayfa, form, yönetici sayfaları, takip, yardım, PWA dosyaları, CSV ve fotoğraf uçları kontrol edildi.

## Otomatik test kapsamı

- Kurulum komutunun tekrar çalıştırılması, 12 seviye ve 17 kategori oluşturulması.
- Gerçek sayılardan ana sayfa istatistikleri; herkese açık çıktılarda kişisel bilgi bulunmaması.
- Doğru sınıfa bildirim kaydı, soru cevaplarının kalıcı saklanması.
- Yönetici sayfaları, raporlar ve fotoğraflarda yetki kontrolü.
- İlk girişte şifre değiştirme zorunluluğu; yanlış eski şifrenin reddi.
- Şifre değişince başka tarayıcı oturumlarının da geçersiz olması.
- İki aktif arıza varken sınıfın erken çözüldü görünmemesi; yeniden açma ve arşivden çıkarma.
- Çözüme geçerken teknik not zorunluluğu.
- Tekrarlanan gönderimin ikinci kayıt yaratmaması; yeni formun yeni kayıt oluşturması.
- Sınıfta mevcut arıza olduğunda farklı sorun onayının istenmesi.
- Görüntü doğrulama, EXIF temizleme, yöneticiye özel fotoğraf erişimi.
- Sahte görüntü/SVG, fazla fotoğraf reddi; yarım yüklemelerin temizlenmesi.
- Gemini başarı, zaman aşımı, geçersiz indeks ve analiz hatası senaryoları.
- Analiz başarısız olsa bile arıza kaydının korunması.
- Gemini'ye ad/iletişim/açıklama gönderilmemesi; devre dışı bırakıldığında API çağrılmaması.
- Soru cevabı doğrulama, başkasının soru oturumuna erişimin engellenmesi, önceki soruya dönüş.
- Şube ekleme/tekrarlı şube engelleme ve açık arızalı şubenin pasifleştirilememesi.
- CSV formül enjeksiyonu önleme, filtre tutarlılığı ve sınıf adına göre arama.
- Gerçek CSRF etkinliği: tokensız istek reddi, token ile başarılı istek.
- Giriş hız limiti: altıncı dakika içi giriş denemesine HTTP 429.
- PWA dosyaları, güvenlik başlıkları, Jinja XSS kaçışı ve QR PNG üretimi.
- Hatalı soru kataloğu ve pasif sınıfa bildirim reddi.

## Yeni sürüm testleri

- Sınıf seçmeden e-posta, K12 ve diğer teknik destek talebi oluşturma.
- Hesap bilgisinin herkese açık çıktılara sızmaması; yönetici ve CSV filtrelerinde doğru konu.
- Yanlış hizmet/kategori ve eksik hesap doğrulaması; bu akışlarda Gemini çağrısı yapılmaması.
- Yeni taleplerin tahta durum istatistiklerini etkilememesi.
- Üretimde localhost adresinin reddi; QR kodunda yapılandırılan alan adının kullanılması.
- Önceki migration şemasındaki gerçek ilişkili kayıt örneğinin yeni sürüme taşınması: cevap, fotoğraf bağlantısı, müdahale notu ve durum geçmişinin korunması; SQLite yabancı anahtar ve CHECK kısıtları.

## Doğrulanamayan alanlar

- **Tam uçtan uca tarayıcı testi:** önizleme servisi Flask çalıştıramadığı için gerçek Flask şablonlarından üretilmiş statik test sayfaları kullanıldı. Chrome içinde 390 px genişlikte ana sayfa, e-posta formu ve yükleme rehberi görsel olarak kontrol edildi. E-posta formunda alan doldurma, adım geçişleri ve gönderim özeti; Android/iPhone rehberi geçişi doğrulandı. Tarayıcıdan gerçek sunucuya gönderim bu önizlemede çalıştırılmadı; kayıt uçları Flask test istemcisiyle test edildi.
- **Canlı Gemini:** kullanıcı API anahtarı bulunmadığından gerçek servis çağrısı yapılmadı. Başarı/hata senaryoları mock ile test edildi. Seçilen modelin hesap erişimi ve kotası kurulumda kontrol edilmelidir.
- **Android/iPhone yükleme:** gerçek telefon üzerinde kurulup denenmedi. Manifest, ikonlar, Service Worker ve iOS meta etiketleri dahildir.
- **Üretim Docker/Caddy/HTTPS, Nginx, Redis ve PostgreSQL:** örnek yapılandırmalar/mimari desteği hazır; bu ortamda Docker CLI bulunmadığı için container build/çalıştırma ve canlı sunucu dağıtımı yapılmadı. Bu servislerle entegrasyon testi tamamlandı iddiasında bulunulmaz.
- Yük/stres testi ve bağımsız güvenlik denetimi yapılmadı.

## Yayın öncesi kısa kabul akışı

1. HTTPS ortamında ilk yönetici şifresini değiştirin ve gerçek şubeyi ekleyin.
2. Telefon ve masaüstünden fotoğraflı bir deneme bildirimi gönderin; üç soruyu ve geri düğmelerini deneyin.
3. Yönetici hesabında fotoğrafı, cevapları ve durum geçmişini kontrol edin; çözülmüş bildirimi yeniden açın.
4. Gemini anahtarını kapatarak tekrar bildirim gönderin; etkinleştirip canlı model erişimini ayrıca doğrulayın.
5. iPhone/Android ana ekrana eklemeyi ve internet kapalıyken uyarı sayfasını kontrol edin.
6. Veri yedeğini alın ve ayrı ortamda geri yükleyin.

Teslim ZIP'inde test/örnek veritabanı, gerçek `.env`, API anahtarı ve yüklenmiş fotoğraflar bulunmaz.

# Bilgi Koleji — Destek Merkezi

Python Flask, kalıcı veritabanı ve Türkçe öğretmen/yönetici arayüzleri içeren çalışır web uygulaması.

## VPS üzerinde kurulum (önerilen)

Yeni sürüm; Bilgi Koleji logosu, sade mobil ana sayfa, dört destek konusu, kısa kullanım turu ve Android/iPhone ana ekrana ekleme rehberi içerir. Yönetici araçları herkese açık ana sayfadan ayrılmıştır.

**VPS kurulumuna `VPS_KURULUM.md` dosyasından başlayın.** Docker Compose; Gunicorn, Redis ve Caddy yapılandırmalarını içerir. Gerçek alan adı gerekir; `configure.py` doğru HTTPS/QR adresini ayarlar ve mevcut SECRET_KEY değerini korur.

### Destek konuları

- Akıllı tahta: sınıf, arıza açıklaması, gözlem soruları ve isteğe bağlı fotoğraf.
- E-posta: hesap adresiyle şifre sıfırlama **talebi**. Şifre otomatik değişmez; teknik sorumlu kimlik doğrulamasından sonra işlem yapar.
- K12: kullanıcı hesabı, sorun konusu ve yazılı açıklama.
- Diğer teknik destek: bilgisayar, yazıcı ve diğer ihtiyaçlar.

E-posta/K12 talepleri sınıf seçmeden oluşturulur. Hesap bilgileri yalnız yöneticiye görünür; bu talepler Gemini'ye gönderilmez. SMTP bildirimi veya K12 hesabına otomatik müdahale entegrasyonu yoktur; talepler yönetici panelinden takip edilir.

## Yerel geliştirme için hızlı başlangıç

Python **3.12 veya daha yeni** sürüm önerilir. ZIP'i çıkarın ve bu README'nin bulunduğu `akilli-tahta` klasöründe terminal açın.

### Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
Copy-Item .env.example .env
.venv\Scripts\python -c "import secrets; print(secrets.token_hex(32))"
```

Son komutun ürettiği değeri `.env` içindeki `SECRET_KEY=` karşısına yapıştırın. Ardından:

```powershell
.venv\Scripts\python -m flask --app run db upgrade
.venv\Scripts\python -m flask --app run seed
.venv\Scripts\python run.py
```

### Linux / macOS

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp .env.example .env
.venv/bin/python -c 'import secrets; print(secrets.token_hex(32))'
```

Üretilen rastgele değeri `.env` dosyasındaki `SECRET_KEY=` alanına yazın. Ardından:

```bash
.venv/bin/python -m flask --app run db upgrade
.venv/bin/python -m flask --app run seed
.venv/bin/python run.py
```

Tarayıcıda **http://127.0.0.1:5000/** adresini açın. `run.py` geliştirme içindir; debug kapalıdır. Üretimde `VPS_KURULUM.md` içindeki Docker yöntemini kullanın.

### İlk yönetici girişi

- Adres: `/yonetici/giris`
- Kullanıcı adı: **emre**
- İlk kurulum şifresi: **akilitahtalar123456**
- İlk girişte şifre değişimi zorunludur. Yeni şifre en az 12 karakter olmalı; değişimden sonra tekrar giriş yapılır.
- İsterseniz ilk `seed` çalıştırmasından önce `.env` içinde `INITIAL_ADMIN_PASSWORD` tanımlayın. Bu değişken mevcut hesabın şifresini değiştirmez. Kurulumdan sonra kaldırın.
- Yönetim Paneli → **Sınıf ve Şubeler** bölümünden gerçek şubeleri ekleyin. Başlangıçta 1–12 seviyeleri vardır; sahte şube veya arıza kaydı oluşturulmaz.
- Ayarlar bölümünde kurum adı, logo, Gemini etkinliği ve saklama inceleme süresini düzenleyin.

`seed` tekrar çalıştırılabilir: mevcut hesap, şifre, sınıf ve kayıtlar korunur.

## Mimari ve dosya yapısı

| Katman | Görev |
|---|---|
| Flask application factory | Yapılandırma, güvenlik başlıkları, hata yönetimi, CLI |
| `routes/public.py` | Ana sayfa, anonim bildirim, soru akışı, kişisel veri içermeyen takip |
| `routes/auth.py` | Yönetici girişi, zorunlu ilk parola değişimi, çıkış |
| `routes/admin.py` | Bildirim yönetimi, sınıflar, kategoriler, ayarlar, QR, CSV |
| `services/questions.py` | Kategori bazlı güvenli gözlem soruları ve doğrulama |
| `services/gemini.py` | Sunucu taraflı Gemini çağrıları, yapılandırılmış çıktı, kesintide yedek |
| `services/uploads.py` | Gerçek görüntü doğrulama, EXIF temizleme, yeniden kodlama |
| `services/issues.py` | Durum değişimi, çözüm tarihleri, müdahale notları |
| SQLAlchemy / Alembic | SQLite ve PostgreSQL için ilişkisel veri ve migration |
| Jinja / CSS / JavaScript | Mobil uyum, beş adımlı form, rehber, canlı durum |

```text
app/
  __init__.py
  extensions.py
  models.py
  forms/
  routes/
  services/
  utils/
  templates/
  static/
config.py
run.py
requirements.txt
.env.example
migrations/
tests/
deploy/
README.md
TEST_NOTLARI.md
```

Tablolar: AdminUser, GradeLevel, Classroom, IssueCategory, Issue, IssueAnswer, IssuePhoto, IssueStatusHistory, MaintenanceNote, AIAnalysis, AppSettings. Draft geçici soru oturumlarını, AuditLog yönetici işlemlerini tutar.

## Öğretmen akışı

1. Sınıf ve ad-soyad seçilir. İletişim bilgisi isteğe bağlıdır.
2. Kategori ve açıklama girilir. Sınıfta aktif arıza varsa farklı bir sorun olduğu onaylanır.
3. Tek tek gösterilen üç gözlem sorusu cevaplanır. Her soruda **Bilmiyorum** vardır. Önceki soruya dönülebilir.
4. İsteğe bağlı en fazla üç fotoğraf seçilir. Her fotoğraf en fazla 5 MB: JPG, PNG, WEBP.
5. Özet kontrol edilerek gönderilir. Gerçek yükleme ilerlemesi gösterilir. Kayıt veritabanına yazıldıktan sonra benzersiz numara verilir.

Önceki adımlara dönüldüğünde alanlar korunur. Kategori değişirse sorular yeniden başlar. Sayfayı tamamen kapatma/yenileme sonrası form alanlarının tamamı tarayıcıda kalıcı saklanmaz; kişisel bilgiler localStorage'a yazılmaz. Soru oturumu 8 saat geçerlidir.

Aynı gönderimin ağ nedeniyle yeniden denenmesi `submission_key` benzersizlik kısıtıyla ikinci kayıt oluşturmaz. Yeni form açılması yeni gönderim anahtarı üretir. Bir tarayıcı oturumunda aynı anda tek form üzerinde çalışılması önerilir.

## Durum ve geçmiş kuralları

- Bir sınıfta en az bir **Sorun Bildirildi** kaydı varsa kart kırmızıdır.
- Bildirilmiş kayıt yok, en az bir **İnceleniyor** kaydı varsa turuncudur.
- Tüm kayıtlar çözülmüşse **Çözüldü**, hiç kayıt yoksa **Sorun Yok** gösterilir.
- Arşivlenmiş arızalar da sınıfın geçmişine dahildir.
- Çözüme geçerken teknik not zorunludur. Çözüm zamanı ve işlem geçmişi korunur.
- Yeniden açmada aktif çözüm tarihi temizlenir; eski çözüm olayı geçmişte kalır; kayıt arşivden çıkarılır.
- Açık arızası olan şube pasifleştirilemez. Şube silme endpoint'i bulunmaz.
- Durumlar Sınıflar sayfasında her 30 saniyede yenilenir. Yenileme başarısızsa eski bilginin güncel olmayabileceği belirtilir.

## Gemini yapılandırması

`.env`:

```dotenv
GEMINI_API_KEY=SUNUCUDAKI_GERCEK_API_ANAHTARI
GEMINI_MODEL=gemini-3.8-flash
```

Model adı yapılandırılabilir. Hesabınızda erişilebilir, `generateContent` ve JSON şemalı çıktı destekleyen modeli kullanın. Uygulamayı yeniden başlatın. Yönetici Ayarlar → Gemini desteği açık olmalıdır.

İlk çalıştırma için API anahtarı **gerekmez**. API anahtarı yoksa, kapalıysa, öğretmen istemezse veya API başarısızsa standart sorular kullanılır. Hatalı model, kota, bağlantı ve JSON sorunları kaydı engellemez.

### Tasarım kararı: onaylı sorular arasından uyarlanabilir seçim

Gemini yeni ve denetlenmemiş bir teknik talimatı doğrudan öğretmene göstermez. Her kategorinin 3–7 onaylı soru kataloğundan cevaplara göre en faydalı sonraki sorunun indeksini seçer. Sunucu bu indeksi doğrular. Öğretmene üç soru sorulur; katalogdaki ek sorular uyarlanabilir seçim için alternatiflerdir. Böylece 3–5 soru hedefinin alt sınırı kullanılır ve hiçbir zaman yedi soru aşılmaz.

Yönetici kategori ve katalogları JSON biçiminde düzenleyebilir. Kataloglar sunucuda doğrulanır. Yönetici yalnızca güvenli gözlem soruları yazmalıdır; bu alan teknik sorumlu içindir.

Gönderim sonrasında yalnızca kategori ve seçilmiş cevaplarla **teknik sorumlu için** olası neden/kontrol analizi istenir. Öğretmen adı, iletişim, serbest açıklama ve fotoğraflar Gemini'ye gönderilmez. Analiz alanları tür/uzunluk kontrollerinden geçirilir; HTML olarak işlenmez. Başarılı bir analiz yoksa sahte analiz oluşturulmaz. Asıl arıza, dış API çağrısından **önce** commit edilir.

Bağlantı/okuma zaman aşımı 3/8 saniyedir. API anahtarı tarayıcıya ve loglara yazılmaz. Hata logu yalnız istisna sınıfını içerir. Sürekli kesintide yönetici AI desteğini kapatabilir. API bütçesi için sağlayıcı tarafındaki kotaları da belirleyin.

Referans: [Google Gemini structured outputs](https://ai.google.dev/gemini-api/docs/structured-output), [Generate Content API](https://ai.google.dev/api/generate-content).

## Güvenlik uygulamaları

- scrypt parola hash'i; ilk girişte şifre değişimi.
- Flask-Login oturumu; 8 saat oturum süresi, HttpOnly, SameSite=Lax. Üretimde Secure çerezi.
- Tüm veri değiştiren isteklerde CSRF; fetch/XHR isteklerinde `X-CSRFToken`.
- Giriş: 5/dakika ve 30/saat. Bildirim: 8/saat, 25/gün. Soru başlatma: 20/saat. Ortak okul IP'sindeki kullanıcı sayısına göre `routes` içindeki limitler kurum tarafından ayarlanmalıdır.
- Üretimde Redis zorunlu; memory:// yalnız geliştirme içindir. Uygulama üretimde memory:// ile başlatılmaz.
- ORM sorguları, Jinja otomatik kaçış ve tarayıcıda textContent; CSP, X-Frame-Options, nosniff.
- CSV hücrelerinde formül enjeksiyonu etkisizleştirilir.
- Fotoğraflar gerçek dosya içeriğinden doğrulanır, piksel sınırı uygulanır, 1920 px'e küçültülür, yeni JPEG olarak metadata olmadan kaydedilir. En fazla 3 × 5 MB, toplam istek sınırı 17 MB.
- Fotoğraflar `instance/uploads/` içinde tutulur; `/static` altında değildir. Yalnız oturum açmış yönetici servis eder. Kurum logosu bilinçli olarak herkese açıktır.
- Kişisel bilgiler ve API yanıtları Service Worker önbelleğine alınmaz. Dinamik yanıtlar `Cache-Control: no-store` taşır.
- Yönetici değişiklikleri AuditLog'a, arıza durumları ayrıca kendi geçmişine yazılır.
- Arıza numarası gizli erişim anahtarı değildir. Herkese açık takip ekranı yalnız sınıf/durum/zaman gösterir.

## PWA / telefon kullanımı

Manifest, 192/512 PNG ikonları, iOS meta etiketleri ve Service Worker dahildir. HTTPS veya localhost gerekir.

- Android Chrome: tarayıcı menüsü → Uygulamayı yükle / Ana ekrana ekle. Tarayıcı izin verirse Telefonuma Ekle sayfasında yükleme düğmesi görünür.
- iPhone Safari: Paylaş → Ana Ekrana Ekle.
- Açılış görünümünü işletim sistemi manifest/ikon bilgilerinden üretir; her iPhone boyutu için ayrı launch image dosyası üretilmemiştir.
- Çevrimdışı: statik uyarı sayfası. Kuyruğa alma/sessiz arka plan gönderimi yoktur; gönderim başarılıymış gibi gösterilmez.
- Statik dosyaları değiştirerek sürüm yayınladığınızda `sw.js` içindeki `CACHE` sürümünü artırın.

## Alternatif: Docker kullanmadan Gunicorn + Nginx + HTTPS

1. Projeyi `/srv/akilli-tahta` içine yerleştirin. Özel `tahta` sistem kullanıcısı oluşturun; yalnız bu kullanıcı uygulama ve `instance/` verilerine erişebilsin.
2. Sanal ortam ve paketleri kurun. `.env` oluşturun; chmod 600 yapın. Aşağıdaki değişkenleri ayarlayın:

```dotenv
APP_ENV=production
SECRET_KEY=RASTGELE_EN_AZ_32_KARAKTER
RATELIMIT_STORAGE_URI=redis://127.0.0.1:6379/0
PUBLIC_BASE_URL=https://destek.kurumunuz.com
TRUST_PROXY=1
```

3. Redis'i yalnız loopback/private ağda çalıştırın. İlk kurulum için `flask --app run db upgrade` ve `flask --app run seed` çalıştırın.
4. `deploy/tahta.service` dosyasını `/etc/systemd/system/tahta.service` olarak kurun. Kullanıcı ve dizinlerin sunucunuzla eşleştiğini kontrol edin. Servisi başlatın.
5. `deploy/nginx.conf` içindeki domain ve TLS sertifika yollarını gerçek değerlerle değiştirin. Sertifikayı güvenilir bir ACME sağlayıcısı üzerinden kurun. Nginx yapılandırmasını `nginx -t` ile doğrulayın ve etkinleştirin.
6. Gunicorn yalnız `127.0.0.1:8000` dinler. Dışarıya yalnız Nginx 80/443 açılır. `instance/`, `.env` veya proje kökünü Nginx static dizini olarak sunmayın.
7. `TRUST_PROXY=1` yalnız tam olarak **bir güvenilir ters proxy** arkasında açılmalıdır. Nginx gelen X-Forwarded-For bilgisini `$remote_addr` ile değiştirir. Gunicorn'a doğrudan dış erişim vermeyin.

Elle çalıştırma:

```bash
.venv/bin/gunicorn --workers 2 --threads 4 --timeout 60 --bind 127.0.0.1:8000 run:app
```

Bu pakette gerçek domain/TLS kurulumu yapılmamıştır. Sunucuya kopyalayıp yayımlama adımı size aittir. PWA kurulumu, telefonla erişilecek HTTPS adresi açıldıktan sonra cihazlarda doğrulanmalıdır.

### PostgreSQL'e geçiş

Boş PostgreSQL veritabanında `.env` içindeki `DATABASE_URL` değerini ayarlayın:

```dotenv
DATABASE_URL=postgresql+psycopg://tahta:PAROLA@127.0.0.1/tahta
```

`flask --app run db upgrade` ve `flask --app run seed` çalıştırın. Mevcut SQLite kayıtları bu komutla otomatik taşınmaz; mevcut veriler için kontrollü veri aktarımı ve yedek gerekir. PostgreSQL mimari olarak desteklenir; bu teslimatta testler SQLite üzerinde çalıştırılmıştır.

### Yedekleme ve bakım

SQLite kullanırken veritabanını SQLite backup API ile tutarlı biçimde yedekleyin; fotoğraflarla eşzamanlı snapshot için uygulamayı bakım penceresinde durdurun. `instance/tahta.db`, `instance/uploads/` ve güvenli `.env` yedeğini birlikte koruyun. PostgreSQL'de `pg_dump` ve fotoğraf yedeklerini kullanın. Geri yüklemeyi ayrı ortamda sınayın.

Geçici soru oturumlarını günlük temizlemek için:

```bash
.venv/bin/flask --app run cleanup-drafts
```

Bu komut yalnız 24 saatten eski Draft kayıtlarını temizler; arıza geçmişini silmez. Arıza arşivleme yönetici panelindedir. Saklama süresi dolan kayıtlar Ayarlar'da sayılır; otomatik silme yoktur. Kurum kendi veri sorumlusu iletişim ve işleme/aktarım metnini yayından önce `privacy.html` içinde tamamlamalıdır. Saklama inceleme süresi tek başına hukuki uyum garantisi değildir.

## Testler

```bash
.venv/bin/python -m pytest -q
# Windows:
.venv\Scripts\python -m pytest -q
```

Testler geçici SQLite ve geçici fotoğraf klasörleri kullanır, gerçek okul verisini etkilemez. API başarı/kesinti/hatalı çıktı durumları taklit edilir; gerçek Gemini anahtarı gerekmez. Son doğrulama kapsamı ve sınırları `TEST_NOTLARI.md` dosyasındadır.

## Sık karşılaşılan durumlar

- **SECRET_KEY hatası:** `.env.example` içindeki yer tutucuyu en az 32 karakter rastgele değerle değiştirin.
- **no such table:** `flask --app run db upgrade` ve `seed` komutlarını çalıştırın.
- **Şube listesi boş:** Yönetici → Sınıf ve Şubeler → ekle. Başlangıçta bilerek şube oluşturulmaz.
- **Yerelde giriş olmuyor:** HTTP geliştirmede `APP_ENV=development`; HTTPS üretimde `production` kullanın.
- **429:** IP hız limiti doldu. Sürenin dolmasını bekleyin; okulun ortak IP ihtiyacına göre limitleri ayarlayın.
- **CSRF/oturum süresi:** Sayfayı yenileyin ve yeniden deneyin.
- **Gemini çalışmıyor:** Bildirimler standart sorularla devam eder; anahtar/model/kota durumunu sunucuda kontrol edin.
- **Bir formda yeni bildirim eski numaraya dönüyor:** Aynı gönderimi tekrar deniyorsunuz. Yeni bildirim için başarı ekranındaki düğmeyi veya ana sayfadan yeni formu açın.
